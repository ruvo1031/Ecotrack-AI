# AI for Climate Action & Sustainability — Development Plan

## Top-Level Overview

Build a small, beginner-friendly, educational web application using **Python** and **Streamlit**.
The user enters lifestyle and consumption data, and the app calculates their estimated personal
carbon footprint, scores their sustainability, surfaces their worst-offending activities, and
produces simple AI-driven recommendations with projected CO₂ savings.

Data is persisted locally to a **JSON file** per session/user.
Business logic lives in plain Python modules; Streamlit is only a thin UI wrapper.
A small pytest suite covers every core calculation and validation rule.

**Non-goals**
- No real-time scientific emission databases
- No external AI/LLM API required
- No user authentication or database
- No multi-user concurrency

---

## Project Architecture

```
climate_ai/
│
├── app.py                     # Streamlit entry point — UI only
│
├── models/
│   ├── __init__.py
│   ├── user_profile.py        # UserProfile dataclass
│   └── emission_data.py       # EmissionData dataclass (all raw inputs)
│
├── core/
│   ├── __init__.py
│   ├── emission_factors.py    # All CO₂ constants — single source of truth
│   ├── calculator.py          # FootprintCalculator — all emission math
│   ├── scorer.py              # SustainabilityScorer
│   ├── recommender.py         # ClimateRecommender (rule-based AI)
│   └── goal_tracker.py        # SustainabilityGoal + GoalTracker
│
├── utils/
│   ├── __init__.py
│   ├── validator.py           # InputValidator
│   └── storage.py             # DataStorage (JSON read/write)
│
├── data/
│   └── user_data.json         # Runtime data file (git-ignored)
│
├── tests/
│   ├── __init__.py
│   ├── test_calculator.py
│   ├── test_scorer.py
│   ├── test_recommender.py
│   ├── test_goal_tracker.py
│   └── test_validator.py
│
├── requirements.txt
└── README.md
```

---

## Component Responsibilities

| Component | Module | Responsibility |
|---|---|---|
| User Profile | `models/user_profile.py` | Hold name, country, household size, diet type |
| Environmental Data Input | `models/emission_data.py` | Hold all raw user consumption inputs |
| Emission Factors | `core/emission_factors.py` | Define all CO₂ constants as a frozen dataclass |
| Carbon Footprint Calculator | `core/calculator.py` | Compute per-category and total CO₂ from raw inputs |
| Sustainability Scorer | `core/scorer.py` | Convert total footprint to a 0–100 score + label |
| AI Recommendation Engine | `core/recommender.py` | Identify top emitters and map to practical actions |
| Goal Tracker | `core/goal_tracker.py` | Store goal, compute target, track progress % |
| Input Validator | `utils/validator.py` | Validate all inputs before any calculation |
| Data Storage | `utils/storage.py` | Save/load full session state to/from JSON |
| Streamlit Dashboard | `app.py` | Render all UI — calls core modules, never calculates |

---

## Data Fields

### `UserProfile`
| Field | Type | Notes |
|---|---|---|
| `name` | `str` | Display name, required |
| `country` | `str` | Used for context only in v1 |
| `household_size` | `int` | 1–20, used to split electricity emissions |
| `diet_type` | `str` | `"omnivore"` / `"vegetarian"` / `"vegan"` |

### `EmissionData` — Electricity
| Field | Type | Notes |
|---|---|---|
| `electricity_kwh_per_month` | `float` | Monthly household kWh |
| `uses_renewable_energy` | `bool` | Reduces factor if True |

### `EmissionData` — Vehicle / Fuel
| Field | Type | Notes |
|---|---|---|
| `car_km_per_week` | `float` | Weekly distance driven |
| `fuel_type` | `str` | `"petrol"` / `"diesel"` / `"electric"` / `"none"` |
| `car_passengers` | `int` | 1–8, divides per-person share of emissions |

### `EmissionData` — Public Transport
| Field | Type | Notes |
|---|---|---|
| `bus_km_per_week` | `float` | |
| `train_km_per_week` | `float` | |

### `EmissionData` — Air Travel
| Field | Type | Notes |
|---|---|---|
| `short_flights_per_year` | `int` | Flights under 3 hours |
| `long_flights_per_year` | `int` | Flights over 6 hours |

### `EmissionData` — Food
| Field | Type | Notes |
|---|---|---|
| `beef_meals_per_week` | `int` | 0–21 |
| `dairy_servings_per_day` | `int` | 0–10 |
| `local_food_percent` | `int` | 0–100, reduces food transport emissions |

### `EmissionData` — Waste
| Field | Type | Notes |
|---|---|---|
| `waste_kg_per_week` | `float` | Total household waste |
| `recycling_percent` | `int` | 0–100, reduces effective waste emissions |

### `SustainabilityGoal`
| Field | Type | Notes |
|---|---|---|
| `baseline_kg` | `float` | Total footprint when goal was created |
| `reduction_percent` | `int` | 5–50 |
| `target_kg` | `float` | Calculated: baseline × (1 − reduction/100) |
| `current_kg` | `float` | Updated on each new calculation |

---

## Emission Factors

All factors live in `core/emission_factors.py` as a single frozen dataclass.
Units are **kg CO₂ per unit** of consumption.

### Electricity
| Factor | Value | Unit |
|---|---|---|
| `electricity_grid` | `0.40` | kg CO₂ / kWh |
| `electricity_renewable` | `0.05` | kg CO₂ / kWh (residual lifecycle) |

**Formula:**
```
factor = renewable_factor if uses_renewable else grid_factor
annual_kwh = kwh_per_month × 12
electricity_kg = (annual_kwh × factor) / household_size
```

### Vehicle / Fuel
| Factor | Value | Unit |
|---|---|---|
| `petrol_per_km` | `0.21` | kg CO₂ / km |
| `diesel_per_km` | `0.17` | kg CO₂ / km |
| `electric_per_km` | `0.05` | kg CO₂ / km |

**Formula:**
```
annual_km = km_per_week × 52
vehicle_kg = (annual_km × fuel_factor) / passengers
```

### Public Transport
| Factor | Value | Unit |
|---|---|---|
| `bus_per_km` | `0.089` | kg CO₂ / km |
| `train_per_km` | `0.041` | kg CO₂ / km |

**Formula:**
```
transport_kg = (bus_km_per_week × 52 × bus_factor)
             + (train_km_per_week × 52 × train_factor)
```

### Air Travel
| Factor | Value | Unit |
|---|---|---|
| `short_flight_kg` | `255` | kg CO₂ / flight (avg ~800 km round-trip) |
| `long_flight_kg` | `1_620` | kg CO₂ / flight (avg ~10,000 km round-trip) |

**Formula:**
```
flight_kg = (short_flights × short_factor) + (long_flights × long_factor)
```

### Food
| Factor | Value | Unit |
|---|---|---|
| `beef_per_meal` | `3.0` | kg CO₂ / meal |
| `dairy_per_serving` | `0.6` | kg CO₂ / serving |
| `diet_base_omnivore` | `1_500` | kg CO₂ / year (baseline) |
| `diet_base_vegetarian` | `1_000` | kg CO₂ / year |
| `diet_base_vegan` | `700` | kg CO₂ / year |
| `local_food_saving_rate` | `0.10` | Max 10% saving from local food (of base) |

**Formula:**
```
beef_annual   = beef_meals_per_week × 52 × beef_factor
dairy_annual  = dairy_servings_per_day × 365 × dairy_factor
local_saving  = diet_base × (local_food_percent / 100) × local_saving_rate
food_kg = diet_base + beef_annual + dairy_annual − local_saving
```

### Waste
| Factor | Value | Unit |
|---|---|---|
| `waste_per_kg` | `0.57` | kg CO₂ / kg waste |

**Formula:**
```
annual_waste = waste_kg_per_week × 52
effective_waste = annual_waste × (1 − recycling_percent / 100)
waste_kg = effective_waste × waste_factor
```

### Total
```
total_kg = electricity_kg + vehicle_kg + transport_kg
         + flight_kg + food_kg + waste_kg
```

---

## Classes and Responsibilities

### `models/user_profile.py`
```
class UserProfile:
    Fields: name, country, household_size, diet_type
    - Validates own fields on construction via InputValidator
    - Exposes a to_dict() / from_dict() for serialization
```

### `models/emission_data.py`
```
class EmissionData:
    Fields: all consumption inputs listed above
    - Plain dataclass with defaults of 0 / False / "none"
    - Exposes to_dict() / from_dict()
```

### `core/emission_factors.py`
```
@dataclass(frozen=True)
class EmissionFactors:
    - All constants as class-level float/int attributes
    - Single instance: FACTORS = EmissionFactors()
    - No methods — data only
```

### `core/calculator.py`
```
class FootprintCalculator:
    - Receives EmissionData + UserProfile
    - Methods:
        calc_electricity_emissions() -> float
        calc_vehicle_emissions()     -> float
        calc_transport_emissions()   -> float
        calc_flight_emissions()      -> float
        calc_food_emissions()        -> float
        calc_waste_emissions()       -> float
        calc_all() -> dict[str, float]   # category name -> kg value
        calc_total() -> float
        get_highest_category() -> str
```

### `core/scorer.py`
```
class SustainabilityScorer:
    GLOBAL_AVERAGE_KG = 4_000   # reference baseline
    MAX_BAD_KG        = 20_000  # anything above scores 0

    Methods:
        calculate_score(total_kg: float) -> int     # 0–100
        get_label(score: int) -> str                # "Excellent" / "Good" / "Fair" / "Poor"
        get_comparison_message(total_kg) -> str     # vs global average
```

Score formula (linear, clamped):
```
raw = (MAX_BAD_KG - total_kg) / (MAX_BAD_KG - 0)
score = max(0, min(100, int(raw * 100)))
```

### `core/recommender.py`
```
class ClimateRecommender:
    - Holds a RECOMMENDATION_MAP: dict[category -> list[Action]]
    - Each Action has: title, description, reason_template, saving_kg_per_year

    Methods:
        get_top_categories(emissions: dict, n: int = 3) -> list[str]
        get_recommendations(emissions: dict) -> list[Recommendation]
        explain_recommendation(rec: Recommendation, emissions: dict) -> str
```

**Rule-based AI logic:**
1. Sort categories by kg descending
2. Take top N categories
3. Look up each category in RECOMMENDATION_MAP
4. Return the top 2–3 actions per category
5. Populate `reason_template` with the user's actual values (e.g., "Your flights emit X kg/year")
6. Include a `saving_kg` estimate per action

### `core/goal_tracker.py`
```
class SustainabilityGoal:
    Fields: baseline_kg, reduction_percent, target_kg, current_kg

class GoalTracker:
    Methods:
        create_goal(baseline_kg, reduction_percent) -> SustainabilityGoal
        update_progress(goal, current_kg) -> SustainabilityGoal
        get_progress_percent(goal) -> float       # 0.0–100.0
        is_goal_met(goal) -> bool
        get_status_message(goal) -> str
```

### `utils/validator.py`
```
class InputValidator:
    @staticmethod validate_non_negative(value, field_name) -> None   # raises ValidationError
    @staticmethod validate_range(value, min, max, field_name) -> None
    @staticmethod validate_choice(value, choices, field_name) -> None
    @staticmethod validate_required(value, field_name) -> None
    @staticmethod validate_emission_data(data: EmissionData) -> None  # runs all checks
    @staticmethod validate_user_profile(profile: UserProfile) -> None
```

### `utils/storage.py`
```
class DataStorage:
    Methods:
        save(profile: UserProfile, data: EmissionData, goal: SustainabilityGoal | None) -> None
        load() -> tuple[UserProfile, EmissionData, SustainabilityGoal | None]
        data_exists() -> bool
        clear() -> None
```

---

## Required Methods / Functions Summary

| Method | Class | Returns |
|---|---|---|
| `calc_electricity_emissions()` | `FootprintCalculator` | `float` |
| `calc_vehicle_emissions()` | `FootprintCalculator` | `float` |
| `calc_transport_emissions()` | `FootprintCalculator` | `float` |
| `calc_flight_emissions()` | `FootprintCalculator` | `float` |
| `calc_food_emissions()` | `FootprintCalculator` | `float` |
| `calc_waste_emissions()` | `FootprintCalculator` | `float` |
| `calc_all()` | `FootprintCalculator` | `dict[str, float]` |
| `calc_total()` | `FootprintCalculator` | `float` |
| `get_highest_category()` | `FootprintCalculator` | `str` |
| `calculate_score()` | `SustainabilityScorer` | `int` |
| `get_label()` | `SustainabilityScorer` | `str` |
| `get_comparison_message()` | `SustainabilityScorer` | `str` |
| `get_top_categories()` | `ClimateRecommender` | `list[str]` |
| `get_recommendations()` | `ClimateRecommender` | `list[Recommendation]` |
| `explain_recommendation()` | `ClimateRecommender` | `str` |
| `create_goal()` | `GoalTracker` | `SustainabilityGoal` |
| `update_progress()` | `GoalTracker` | `SustainabilityGoal` |
| `get_progress_percent()` | `GoalTracker` | `float` |
| `is_goal_met()` | `GoalTracker` | `bool` |
| `save()` | `DataStorage` | `None` |
| `load()` | `DataStorage` | `tuple` |
| `validate_emission_data()` | `InputValidator` | `None` / raises |

---

## Validation Rules

| Field | Rule |
|---|---|
| `electricity_kwh_per_month` | ≥ 0, ≤ 10,000 |
| `car_km_per_week` | ≥ 0, ≤ 5,000 |
| `car_passengers` | int, 1–8 |
| `fuel_type` | one of `petrol`, `diesel`, `electric`, `none` |
| `bus_km_per_week` | ≥ 0, ≤ 2,000 |
| `train_km_per_week` | ≥ 0, ≤ 5,000 |
| `short_flights_per_year` | int, 0–50 |
| `long_flights_per_year` | int, 0–20 |
| `beef_meals_per_week` | int, 0–21 |
| `dairy_servings_per_day` | int, 0–10 |
| `local_food_percent` | int, 0–100 |
| `waste_kg_per_week` | ≥ 0, ≤ 500 |
| `recycling_percent` | int, 0–100 |
| `household_size` | int, 1–20 |
| `reduction_goal_percent` | int, 5–50 |
| `diet_type` | one of `omnivore`, `vegetarian`, `vegan` |
| `name` | non-empty string |

---

## Exception Handling

### Custom Exceptions (all in `utils/exceptions.py`)

| Exception | Parent | When Raised |
|---|---|---|
| `ClimateAppError` | `Exception` | Base for all app exceptions |
| `ValidationError` | `ClimateAppError` | Input fails any validation rule |
| `MissingDataError` | `ClimateAppError` | Calculation attempted with no data |
| `StorageError` | `ClimateAppError` | File read/write fails |
| `CorruptedDataError` | `StorageError` | JSON exists but cannot be parsed |

### Handling Behavior

| Situation | Behavior |
|---|---|
| `ValidationError` | Caught in `app.py`; show `st.error()` with friendly message |
| `MissingDataError` | Caught in `app.py`; prompt user to complete input form |
| `StorageError` | Caught in `app.py`; warn user, proceed with empty state |
| `CorruptedDataError` | Log error, delete corrupt file, start fresh |
| Unexpected `Exception` | Caught at top level in `app.py`; show generic error |

---

## Edge Cases

| Edge Case | Handling |
|---|---|
| All consumption fields = 0 | Valid; produces near-zero footprint; show informational note |
| Any field is negative | `ValidationError` raised before calculation |
| Extremely large values (above max) | `ValidationError` with "value seems unrealistic" message |
| `fuel_type = "none"` + `car_km > 0` | Validator raises `ValidationError`; inconsistent data |
| `recycling_percent = 100` | Waste emissions approach zero — handled by formula, not special case |
| `uses_renewable_energy = True` | Applies lower factor automatically |
| `household_size` > 1 | Electricity emissions divided by household size |
| No high-emission category (all zero) | `get_highest_category()` returns `"none"` — recommender shows general tips |
| Goal already met at creation time | `is_goal_met()` returns True immediately; show congratulations |
| `reduction_percent` outside 5–50 | `ValidationError` |
| Data file missing | `DataStorage.load()` raises `MissingDataError`; handled gracefully |
| Data file corrupted | Raises `CorruptedDataError`; app resets to clean state |
| Recommender finds no actions | Falls back to a list of 3 general climate tips |

---

## AI Recommendation Logic

The "AI" is a **rule-based engine** in `ClimateRecommender`.
No external API or ML model is required.

### Algorithm

```
1. Call calc_all() to get per-category emissions dict
2. Sort categories by kg value, descending
3. Take the top 3 categories
4. For each top category, look up RECOMMENDATION_MAP[category]
5. Return up to 2 actions per category (max 6 recommendations total)
6. For each action, fill in the reason_template with the user's actual value
7. Include saving_kg (a fixed estimated value per action type)
```

### `RECOMMENDATION_MAP` structure

Each entry maps a category name to a list of `Action` objects:

```
"electricity" -> [
    Action(
        title="Switch to a renewable energy tariff",
        description="Many providers offer 100% renewable electricity.",
        reason_template="Your electricity produces {kg:.0f} kg CO₂/year.",
        saving_kg=500
    ),
    Action(
        title="Reduce standby power usage",
        description="Unplug devices when not in use.",
        reason_template="Small changes in daily habits reduce electricity waste.",
        saving_kg=80
    )
]
"vehicle" -> [...]
"flights"  -> [...]
"food"     -> [...]
"waste"    -> [...]
"transport"-> [...]
```

### Personalization

The `reason_template` is filled with the user's own category value, so the
recommendation reads: *"Your flights produce 1,620 kg CO₂/year — here's what you can do."*
This makes the engine feel personalized without any ML.

---

## Sustainability Score Logic

```
GLOBAL_AVERAGE_KG = 4_000
MAX_BAD_KG        = 20_000

raw_score = (MAX_BAD_KG - total_kg) / MAX_BAD_KG
score     = max(0, min(100, int(raw_score * 100)))
```

| Score Range | Label | Message |
|---|---|---|
| 80–100 | Excellent | "Your footprint is well below the global average." |
| 60–79 | Good | "You're doing better than most." |
| 40–59 | Fair | "Room to improve — check the recommendations." |
| 0–39 | Poor | "High footprint — take action now." |

---

## Dashboard Layout (`app.py`)

```
Page: sidebar navigation
│
├── 1. My Profile          → UserProfile form
├── 2. Enter My Data       → EmissionData form (tabbed by category)
├── 3. My Carbon Footprint → Results: total, category breakdown, charts
├── 4. Recommendations     → AI actions, savings estimates
├── 5. My Goals            → Create/view goal, progress bar
└── 6. Climate Tips        → Rotating tips panel
```

Charts to include:
- Horizontal bar chart: kg per category (`st.bar_chart` or `matplotlib`)
- Gauge / metric: sustainability score (`st.metric`)
- Progress bar: goal tracking (`st.progress`)

---

## Testing Strategy

All tests live in `tests/` and use **pytest**.
No Streamlit code is tested — only business logic.

### Test Files

| File | What It Tests |
|---|---|
| `test_calculator.py` | Each `calc_*` method with known inputs and expected outputs |
| `test_scorer.py` | Score formula edge cases: 0 kg, average, max, above max |
| `test_recommender.py` | Top category detection, recommendation count, reason_template fill |
| `test_goal_tracker.py` | Goal creation, progress %, is_goal_met, boundary values |
| `test_validator.py` | Each validation rule: valid pass, each invalid fail case |

### Test Approach

- Each test function covers **one behavior**
- Use explicit numeric inputs so tests are self-documenting
- Include at least one test for each edge case listed above
- No mocking required — all modules are pure logic

---

## Development Steps

Each step below is an independent sub-task. Complete and verify each before moving to the next.

### Sub-Task 1 — Project Scaffolding
**Intent:** Create the folder structure, empty module files, `requirements.txt`, and `README.md`.
**Outcomes:** All files exist; `python -m pytest` runs with 0 errors (no tests yet).
**Steps:**
1. Create all directories and `__init__.py` files
2. Create empty module files (just a comment header)
3. Write `requirements.txt`: `streamlit`, `pytest`
4. Write a one-paragraph `README.md`
**Status:** [ ] pending

### Sub-Task 2 — Exceptions and Emission Factors
**Intent:** Define all custom exceptions and all CO₂ constants before any logic is written.
**Outcomes:** `utils/exceptions.py` and `core/emission_factors.py` are complete and importable.
**Steps:**
1. Write `ClimateAppError`, `ValidationError`, `MissingDataError`, `StorageError`, `CorruptedDataError`
2. Write `EmissionFactors` frozen dataclass with all constants from the plan
3. Create `FACTORS = EmissionFactors()` singleton
**Status:** [ ] pending

### Sub-Task 3 — Data Models
**Intent:** Define `UserProfile` and `EmissionData` dataclasses with serialization.
**Outcomes:** Both classes instantiate, serialize, and deserialize cleanly.
**Steps:**
1. Write `UserProfile` with `to_dict` / `from_dict`
2. Write `EmissionData` with `to_dict` / `from_dict`
**Status:** [ ] pending

### Sub-Task 4 — Input Validator
**Intent:** Implement all validation rules before any logic uses user data.
**Outcomes:** `InputValidator` raises `ValidationError` on all bad inputs; passes valid inputs silently.
**Steps:**
1. Implement all static methods in `InputValidator`
2. Write `tests/test_validator.py` and confirm all pass
**Status:** [ ] pending

### Sub-Task 5 — Carbon Footprint Calculator
**Intent:** Implement all emission calculations against the defined factors.
**Outcomes:** All `calc_*` methods return correct `float` values for known inputs.
**Steps:**
1. Implement each `calc_*` method in `FootprintCalculator`
2. Implement `calc_all()`, `calc_total()`, `get_highest_category()`
3. Write `tests/test_calculator.py` and confirm all pass
**Status:** [ ] pending

### Sub-Task 6 — Sustainability Scorer
**Intent:** Implement the score formula and labels.
**Outcomes:** `calculate_score()` returns 0–100 for all inputs; labels are correct.
**Steps:**
1. Implement `SustainabilityScorer`
2. Write `tests/test_scorer.py` and confirm all pass
**Status:** [ ] pending

### Sub-Task 7 — AI Recommendation Engine
**Intent:** Implement the rule-based recommender with a full `RECOMMENDATION_MAP`.
**Outcomes:** `get_recommendations()` returns populated, personalized recommendations for each category.
**Steps:**
1. Define all `Action` entries in `RECOMMENDATION_MAP`
2. Implement `get_top_categories()` and `get_recommendations()`
3. Implement `explain_recommendation()` with template filling
4. Write `tests/test_recommender.py` and confirm all pass
**Status:** [ ] pending

### Sub-Task 8 — Goal Tracker
**Intent:** Implement goal creation and progress tracking.
**Outcomes:** `GoalTracker` creates valid goals and reports correct progress %.
**Steps:**
1. Implement `SustainabilityGoal` and `GoalTracker`
2. Write `tests/test_goal_tracker.py` and confirm all pass
**Status:** [ ] pending

### Sub-Task 9 — Data Storage
**Intent:** Implement JSON save/load for full session state.
**Outcomes:** A round-trip save + load produces identical objects.
**Steps:**
1. Implement `DataStorage.save()`, `load()`, `data_exists()`, `clear()`
2. Handle `CorruptedDataError` on malformed JSON
**Status:** [ ] pending

### Sub-Task 10 — Streamlit Dashboard
**Intent:** Build the UI that wires all core modules together.
**Outcomes:** `streamlit run app.py` shows a functional multi-page app.
**Steps:**
1. Build sidebar navigation
2. Build Profile page (form → UserProfile)
3. Build Data Entry page (tabbed form → EmissionData)
4. Build Footprint Results page (charts + score + highest category)
5. Build Recommendations page (AI output)
6. Build Goals page (create + progress bar)
7. Build Climate Tips page
**Status:** [ ] pending

---

## Missing / Open Requirements

| Item | Decision Needed |
|---|---|
| **Save file location** | Default to `data/user_data.json` in project root — acceptable for v1 |
| **Multi-user support** | Not in scope; single JSON file per local install |
| **Chart library** | Use `st.bar_chart` for simplicity; upgrade to `plotly` if richer charts wanted |
| **Climate tips content** | A hardcoded list of 10–15 tips in `tips.py` is sufficient |
| **Country-specific grid factor** | v1 uses a single global average of 0.40 kg/kWh |
| **Renewable energy factor = 0.05** | Represents lifecycle emissions (manufacturing panels, etc.), not zero |
| **Food base emissions** | Diet-base values are approximations — acceptable for educational use |
| **Local food saving cap** | Capped at 10% to avoid overclaiming |

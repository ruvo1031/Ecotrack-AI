"""
DataStorage — saves and loads all session data to/from a JSON file.

Format: a single JSON object containing 'profile', 'emission_data', and 'goal'.
Missing or corrupted files are handled gracefully.
"""

from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Optional

from models.user_profile import UserProfile
from models.emission_data import EmissionData
from core.goal_tracker import SustainabilityGoal
from utils.exceptions import StorageError, CorruptedDataError, MissingDataError

# Default path for storing user data — relative to the project root
DEFAULT_DATA_PATH = Path("data") / "user_data.json"


class DataStorage:
    """
    Saves and loads the full user session (profile, emission data, goal)
    to and from a single JSON file on disk.

    Args:
        file_path: Path to the JSON file. Defaults to data/user_data.json.
    """

    def __init__(self, file_path: Path = DEFAULT_DATA_PATH) -> None:
        self._path = file_path

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def data_exists(self) -> bool:
        """Return True if the data file exists on disk."""
        return self._path.exists()

    def save(
        self,
        profile: UserProfile,
        emission_data: EmissionData,
        goal: Optional[SustainabilityGoal],
    ) -> None:
        """
        Persist the user's data to disk.

        Args:
            profile:       The user's profile.
            emission_data: The user's consumption data.
            goal:          The user's sustainability goal, or None.

        Raises:
            StorageError: If the file cannot be written.
        """
        payload = {
            "profile": profile.to_dict(),
            "emission_data": emission_data.to_dict(),
            "goal": goal.to_dict() if goal is not None else None,
        }
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2)
        except OSError as exc:
            raise StorageError(
                f"Could not save data to '{self._path}': {exc}"
            ) from exc

    def load(
        self,
    ) -> tuple[UserProfile, EmissionData, Optional[SustainabilityGoal]]:
        """
        Load the user's data from disk.

        Returns:
            A tuple of (UserProfile, EmissionData, SustainabilityGoal | None).

        Raises:
            MissingDataError:  If the file does not exist.
            CorruptedDataError: If the file exists but cannot be parsed.
        """
        if not self._path.exists():
            raise MissingDataError(
                f"No saved data found at '{self._path}'. "
                "Please enter your data and save first."
            )

        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise CorruptedDataError(
                f"The saved data file at '{self._path}' appears to be corrupted "
                "and could not be read. The file will be reset."
            ) from exc

        try:
            profile = UserProfile.from_dict(payload.get("profile", {}))
            emission_data = EmissionData.from_dict(payload.get("emission_data", {}))
            raw_goal = payload.get("goal")
            goal = SustainabilityGoal.from_dict(raw_goal) if raw_goal else None
        except (KeyError, TypeError, ValueError) as exc:
            raise CorruptedDataError(
                f"The saved data file at '{self._path}' has an unexpected format "
                "and could not be loaded. The file will be reset."
            ) from exc

        return profile, emission_data, goal

    def clear(self) -> None:
        """
        Delete the saved data file if it exists.

        Does nothing if the file is not present.
        """
        if self._path.exists():
            try:
                os.remove(self._path)
            except OSError as exc:
                raise StorageError(
                    f"Could not delete data file at '{self._path}': {exc}"
                ) from exc

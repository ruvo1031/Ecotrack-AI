"""
InputValidator — validates all user inputs before they reach business logic.

All methods are static and raise ValidationError with a clear message on failure.
They return silently when the value is valid, making them safe to call in sequence.
"""

from utils.exceptions import ValidationError


class InputValidator:
    """
    Provides static validation helpers used by the rest of the application.

    Usage example:
        InputValidator.validate_non_negative(value, "electricity_kwh_per_month")
        InputValidator.validate_range(value, 0, 100, "recycling_percent")
    """

    # ------------------------------------------------------------------
    # Primitive checks
    # ------------------------------------------------------------------

    @staticmethod
    def validate_non_negative(value: float, field_name: str) -> None:
        """Raise ValidationError if value is below zero."""
        if value < 0:
            raise ValidationError(
                f"'{field_name}' must be 0 or greater, but got {value}."
            )

    @staticmethod
    def validate_range(
        value: float, minimum: float, maximum: float, field_name: str
    ) -> None:
        """Raise ValidationError if value is outside [minimum, maximum]."""
        if value < minimum or value > maximum:
            raise ValidationError(
                f"'{field_name}' must be between {minimum} and {maximum}, but got {value}."
            )

    @staticmethod
    def validate_choice(value: str, choices: list[str], field_name: str) -> None:
        """Raise ValidationError if value is not in the allowed choices list."""
        if value not in choices:
            raise ValidationError(
                f"'{field_name}' must be one of {choices}, but got '{value}'."
            )

    @staticmethod
    def validate_required(value: str, field_name: str) -> None:
        """Raise ValidationError if a required string field is empty."""
        if not value or not value.strip():
            raise ValidationError(f"'{field_name}' is required and cannot be empty.")

    @staticmethod
    def validate_positive_int(value: int, field_name: str) -> None:
        """Raise ValidationError if an integer is not >= 1."""
        if value < 1:
            raise ValidationError(
                f"'{field_name}' must be at least 1, but got {value}."
            )

    # ------------------------------------------------------------------
    # Composite validators
    # ------------------------------------------------------------------

    @staticmethod
    def validate_user_profile(name: str, household_size: int, diet_type: str) -> None:
        """Validate all UserProfile fields together."""
        from models.user_profile import VALID_DIET_TYPES

        InputValidator.validate_required(name, "name")
        InputValidator.validate_range(household_size, 1, 20, "household_size")
        InputValidator.validate_choice(diet_type, VALID_DIET_TYPES, "diet_type")

    @staticmethod
    def validate_emission_data(
        electricity_kwh_per_month: float,
        car_km_per_week: float,
        fuel_type: str,
        car_passengers: int,
        bus_km_per_week: float,
        train_km_per_week: float,
        short_flights_per_year: int,
        long_flights_per_year: int,
        beef_meals_per_week: int,
        dairy_servings_per_day: int,
        local_food_percent: int,
        waste_kg_per_week: float,
        recycling_percent: int,
    ) -> None:
        """Validate every field of EmissionData."""
        from models.emission_data import VALID_FUEL_TYPES

        InputValidator.validate_range(
            electricity_kwh_per_month, 0, 10_000, "electricity_kwh_per_month"
        )
        InputValidator.validate_range(car_km_per_week, 0, 5_000, "car_km_per_week")
        InputValidator.validate_choice(fuel_type, VALID_FUEL_TYPES, "fuel_type")
        InputValidator.validate_range(car_passengers, 1, 8, "car_passengers")
        InputValidator.validate_range(bus_km_per_week, 0, 2_000, "bus_km_per_week")
        InputValidator.validate_range(
            train_km_per_week, 0, 5_000, "train_km_per_week"
        )
        InputValidator.validate_range(
            short_flights_per_year, 0, 50, "short_flights_per_year"
        )
        InputValidator.validate_range(
            long_flights_per_year, 0, 20, "long_flights_per_year"
        )
        InputValidator.validate_range(
            beef_meals_per_week, 0, 21, "beef_meals_per_week"
        )
        InputValidator.validate_range(
            dairy_servings_per_day, 0, 10, "dairy_servings_per_day"
        )
        InputValidator.validate_range(
            local_food_percent, 0, 100, "local_food_percent"
        )
        InputValidator.validate_range(waste_kg_per_week, 0, 500, "waste_kg_per_week")
        InputValidator.validate_range(recycling_percent, 0, 100, "recycling_percent")

        # Logical consistency: if user says they drive but fuel_type is "none"
        if car_km_per_week > 0 and fuel_type == "none":
            raise ValidationError(
                "You entered driving distance but selected 'none' as fuel type. "
                "Please select a fuel type for your vehicle."
            )

    @staticmethod
    def validate_goal(reduction_percent: int) -> None:
        """Validate a sustainability goal reduction percentage."""
        InputValidator.validate_range(
            reduction_percent, 5, 50, "reduction_goal_percent"
        )

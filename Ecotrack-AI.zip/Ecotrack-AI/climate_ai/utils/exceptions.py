"""
Custom exceptions for the Climate AI application.
"""


class ClimateAppError(Exception):
    """Base exception for all application errors."""


class ValidationError(ClimateAppError):
    """Raised when user input fails a validation rule."""


class MissingDataError(ClimateAppError):
    """Raised when a calculation is attempted with no data."""


class StorageError(ClimateAppError):
    """Raised when a file read or write operation fails."""


class CorruptedDataError(StorageError):
    """Raised when a saved file exists but cannot be parsed."""

"""
app.py — Streamlit dashboard for the AI for Climate Action & Sustainability app.

This file contains only UI logic (forms, display, charts).
All business logic lives in core/ and utils/.

Run with:  streamlit run app.py
"""

import sys
import os

# Allow imports from the climate_ai package root when running via `streamlit run app.py`
sys.path.insert(0, os.path.dirname(__file__))

import random
import streamlit as st

from models.user_profile import UserProfile, VALID_DIET_TYPES
from models.emission_data import EmissionData, VALID_FUEL_TYPES
from core.calculator import FootprintCalculator, ALL_CATEGORIES
from core.scorer import SustainabilityScorer
from core.recommender import ClimateRecommender
from core.goal_tracker import GoalTracker, SustainabilityGoal
from core.tips import CLIMATE_TIPS
from utils.validator import InputValidator
from utils.storage import DataStorage
from utils.exceptions import (
    ValidationError,
    MissingDataError,
    CorruptedDataError,
    StorageError,
)

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI Climate Action Assistant",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)

storage = DataStorage()


# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------
def _init_state() -> None:
    """Initialise Streamlit session state with default values."""
    if "profile" not in st.session_state:
        st.session_state.profile = UserProfile()
    if "emission_data" not in st.session_state:
        st.session_state.emission_data = EmissionData()
    if "goal" not in st.session_state:
        st.session_state.goal = None
    if "emissions_calculated" not in st.session_state:
        st.session_state.emissions_calculated = False
    if "emissions_dict" not in st.session_state:
        st.session_state.emissions_dict = {}
    if "total_kg" not in st.session_state:
        st.session_state.total_kg = 0.0


_init_state()


# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------
st.sidebar.image(
    "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Earth_Eastern_Hemisphere.jpg/240px-Earth_Eastern_Hemisphere.jpg",
    use_container_width=True,
)
st.sidebar.title("🌍 Climate Assistant")
st.sidebar.caption(
    "An educational tool to help you understand and reduce your carbon footprint."
)
st.sidebar.divider()

PAGE_PROFILE = "👤 My Profile"
PAGE_DATA = "📊 Enter My Data"
PAGE_RESULTS = "🌱 My Carbon Footprint"
PAGE_RECOMMENDATIONS = "💡 AI Recommendations"
PAGE_GOALS = "🎯 Sustainability Goals"
PAGE_TIPS = "📚 Climate Tips"

page = st.sidebar.radio(
    "Navigate",
    [PAGE_PROFILE, PAGE_DATA, PAGE_RESULTS, PAGE_RECOMMENDATIONS, PAGE_GOALS, PAGE_TIPS],
)

st.sidebar.divider()
st.sidebar.caption(
    "⚠️ All footprint values are **estimates** for educational purposes only "
    "and are not scientifically precise measurements."
)


# ---------------------------------------------------------------------------
# Helper: calculate and store results
# ---------------------------------------------------------------------------
def _run_calculation() -> None:
    """Run the footprint calculator and store results in session state."""
    calc = FootprintCalculator(
        st.session_state.emission_data, st.session_state.profile
    )
    st.session_state.emissions_dict = calc.calc_all()
    st.session_state.total_kg = calc.calc_total()
    st.session_state.emissions_calculated = True

    # Update goal progress if a goal exists
    if st.session_state.goal is not None:
        st.session_state.goal = GoalTracker.update_progress(
            st.session_state.goal, st.session_state.total_kg
        )


# ===========================================================================
# PAGE: My Profile
# ===========================================================================
if page == PAGE_PROFILE:
    st.title("👤 My Profile")
    st.markdown(
        "Enter your basic information. This helps personalise your carbon footprint estimate."
    )
    st.divider()

    with st.form("profile_form"):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input(
                "Your name", value=st.session_state.profile.name, placeholder="e.g. Alex"
            )
            country = st.text_input(
                "Country", value=st.session_state.profile.country, placeholder="e.g. United Kingdom"
            )
        with col2:
            household_size = st.number_input(
                "Household size (number of people)",
                min_value=1, max_value=20,
                value=st.session_state.profile.household_size,
                step=1,
            )
            diet_type = st.selectbox(
                "Diet type",
                options=VALID_DIET_TYPES,
                index=VALID_DIET_TYPES.index(st.session_state.profile.diet_type),
                help="This affects the food emission baseline.",
            )

        submitted = st.form_submit_button("💾 Save Profile", use_container_width=True)

    if submitted:
        try:
            InputValidator.validate_user_profile(name, household_size, diet_type)
            st.session_state.profile = UserProfile(
                name=name,
                country=country,
                household_size=int(household_size),
                diet_type=diet_type,
            )
            st.success(f"✅ Profile saved for **{name}**!")
        except ValidationError as e:
            st.error(f"❌ {e}")

    # Load / Save / Clear data buttons
    st.divider()
    st.subheader("💾 Data Management")
    col_save, col_load, col_clear = st.columns(3)

    with col_save:
        if st.button("💾 Save All Data", use_container_width=True):
            try:
                storage.save(
                    st.session_state.profile,
                    st.session_state.emission_data,
                    st.session_state.goal,
                )
                st.success("Data saved successfully.")
            except StorageError as e:
                st.error(f"❌ Could not save: {e}")

    with col_load:
        if st.button("📂 Load Saved Data", use_container_width=True):
            try:
                profile, emission_data, goal = storage.load()
                st.session_state.profile = profile
                st.session_state.emission_data = emission_data
                st.session_state.goal = goal
                _run_calculation()
                st.success("Saved data loaded successfully.")
                st.rerun()
            except MissingDataError:
                st.info("No saved data found. Please enter your data first.")
            except CorruptedDataError:
                st.error("Saved data is corrupted. Starting fresh.")
                storage.clear()
            except StorageError as e:
                st.error(f"❌ Load error: {e}")

    with col_clear:
        if st.button("🗑️ Clear All Data", use_container_width=True):
            storage.clear()
            st.session_state.profile = UserProfile()
            st.session_state.emission_data = EmissionData()
            st.session_state.goal = None
            st.session_state.emissions_calculated = False
            st.session_state.emissions_dict = {}
            st.session_state.total_kg = 0.0
            st.success("All data cleared.")
            st.rerun()


# ===========================================================================
# PAGE: Enter My Data
# ===========================================================================
elif page == PAGE_DATA:
    st.title("📊 Enter My Environmental Data")
    st.markdown(
        "Enter your typical consumption. You can update these values at any time."
    )
    st.info(
        "ℹ️ All calculations produce **estimated** CO₂ figures for educational purposes only."
    )
    st.divider()

    ed = st.session_state.emission_data  # shorthand

    tab_elec, tab_vehicle, tab_transport, tab_flights, tab_food, tab_waste = st.tabs(
        ["⚡ Electricity", "🚗 Vehicle", "🚌 Public Transport", "✈️ Flights", "🥗 Food", "🗑️ Waste"]
    )

    # --- Electricity ---
    with tab_elec:
        st.subheader("⚡ Electricity Consumption")
        elec_kwh = st.number_input(
            "Monthly electricity use (kWh)",
            min_value=0.0, max_value=10_000.0,
            value=float(ed.electricity_kwh_per_month),
            step=10.0,
            help="Check your electricity bill for the monthly kWh figure.",
        )
        renewable = st.checkbox(
            "I use a 100 % renewable energy tariff",
            value=ed.uses_renewable_energy,
        )

    # --- Private Vehicle ---
    with tab_vehicle:
        st.subheader("🚗 Private Vehicle Usage")
        fuel_type = st.selectbox(
            "Fuel type",
            options=VALID_FUEL_TYPES,
            index=VALID_FUEL_TYPES.index(ed.fuel_type),
            help="Select 'none' if you do not own or use a private vehicle.",
        )
        car_km = st.number_input(
            "Distance driven per week (km)",
            min_value=0.0, max_value=5_000.0,
            value=float(ed.car_km_per_week),
            step=10.0,
        )
        passengers = st.number_input(
            "Average number of passengers (including you)",
            min_value=1, max_value=8,
            value=int(ed.car_passengers),
            step=1,
        )

    # --- Public Transport ---
    with tab_transport:
        st.subheader("🚌 Public Transport Usage")
        bus_km = st.number_input(
            "Kilometres by bus per week",
            min_value=0.0, max_value=2_000.0,
            value=float(ed.bus_km_per_week),
            step=5.0,
        )
        train_km = st.number_input(
            "Kilometres by train per week",
            min_value=0.0, max_value=5_000.0,
            value=float(ed.train_km_per_week),
            step=5.0,
        )

    # --- Flights ---
    with tab_flights:
        st.subheader("✈️ Air Travel")
        st.caption("Short-haul: flights under ~3 hours. Long-haul: flights over ~6 hours.")
        short_flights = st.number_input(
            "Short-haul flights per year",
            min_value=0, max_value=50,
            value=int(ed.short_flights_per_year),
            step=1,
        )
        long_flights = st.number_input(
            "Long-haul flights per year",
            min_value=0, max_value=20,
            value=int(ed.long_flights_per_year),
            step=1,
        )

    # --- Food ---
    with tab_food:
        st.subheader("🥗 Food Habits")
        beef_meals = st.number_input(
            "Beef-based meals per week",
            min_value=0, max_value=21,
            value=int(ed.beef_meals_per_week),
            step=1,
        )
        dairy_servings = st.number_input(
            "Dairy servings per day (milk, cheese, yoghurt…)",
            min_value=0, max_value=10,
            value=int(ed.dairy_servings_per_day),
            step=1,
        )
        local_food = st.slider(
            "Percentage of food that is locally sourced (%)",
            min_value=0, max_value=100,
            value=int(ed.local_food_percent),
            step=5,
        )

    # --- Waste ---
    with tab_waste:
        st.subheader("🗑️ Household Waste")
        waste_kg = st.number_input(
            "Total waste produced per week (kg)",
            min_value=0.0, max_value=500.0,
            value=float(ed.waste_kg_per_week),
            step=0.5,
        )
        recycling = st.slider(
            "Percentage of waste that is recycled or composted (%)",
            min_value=0, max_value=100,
            value=int(ed.recycling_percent),
            step=5,
        )

    st.divider()
    if st.button("⚡ Calculate My Carbon Footprint", use_container_width=True, type="primary"):
        try:
            InputValidator.validate_emission_data(
                electricity_kwh_per_month=elec_kwh,
                car_km_per_week=car_km,
                fuel_type=fuel_type,
                car_passengers=int(passengers),
                bus_km_per_week=bus_km,
                train_km_per_week=train_km,
                short_flights_per_year=int(short_flights),
                long_flights_per_year=int(long_flights),
                beef_meals_per_week=int(beef_meals),
                dairy_servings_per_day=int(dairy_servings),
                local_food_percent=int(local_food),
                waste_kg_per_week=waste_kg,
                recycling_percent=int(recycling),
            )
            st.session_state.emission_data = EmissionData(
                electricity_kwh_per_month=elec_kwh,
                uses_renewable_energy=renewable,
                car_km_per_week=car_km,
                fuel_type=fuel_type,
                car_passengers=int(passengers),
                bus_km_per_week=bus_km,
                train_km_per_week=train_km,
                short_flights_per_year=int(short_flights),
                long_flights_per_year=int(long_flights),
                beef_meals_per_week=int(beef_meals),
                dairy_servings_per_day=int(dairy_servings),
                local_food_percent=int(local_food),
                waste_kg_per_week=waste_kg,
                recycling_percent=int(recycling),
            )
            _run_calculation()
            st.success(
                f"✅ Calculation complete! Your estimated total is "
                f"**{st.session_state.total_kg:,.0f} kg CO₂/year**. "
                "Go to **My Carbon Footprint** to see the full results."
            )
        except ValidationError as e:
            st.error(f"❌ Input error: {e}")


# ===========================================================================
# PAGE: My Carbon Footprint
# ===========================================================================
elif page == PAGE_RESULTS:
    st.title("🌱 My Estimated Carbon Footprint")
    st.caption(
        "⚠️ These are simplified estimates for educational purposes only, "
        "not scientifically precise measurements."
    )
    st.divider()

    if not st.session_state.emissions_calculated:
        st.info(
            "No results yet. Go to **📊 Enter My Data** and click "
            "**Calculate My Carbon Footprint** first."
        )
    else:
        total_kg = st.session_state.total_kg
        emissions = st.session_state.emissions_dict
        score = SustainabilityScorer.calculate_score(total_kg)
        label = SustainabilityScorer.get_label(score)
        comparison = SustainabilityScorer.get_comparison_message(total_kg)

        calc = FootprintCalculator(
            st.session_state.emission_data, st.session_state.profile
        )
        highest = calc.get_highest_category()

        # --- Top metrics ---
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric(
                "🌍 Total Estimated CO₂",
                f"{total_kg:,.0f} kg/year",
                help="Sum of all category estimates.",
            )
        with col2:
            st.metric(
                "⭐ Sustainability Score",
                f"{score}/100",
                delta=label,
                help=SustainabilityScorer.get_score_explanation(),
            )
        with col3:
            st.metric(
                "🔥 Highest-Impact Category",
                highest,
                help="The category contributing most to your estimated footprint.",
            )

        st.divider()
        st.markdown(f"**{comparison}**")
        st.divider()

        # --- Category breakdown ---
        st.subheader("📊 Estimated Emissions by Category")

        # Bar chart
        chart_data = {cat: emissions.get(cat, 0.0) for cat in ALL_CATEGORIES}
        # Use st.bar_chart with a dict
        import pandas as pd
        df = pd.DataFrame.from_dict(
            {"Estimated CO₂ (kg/year)": chart_data}
        )
        st.bar_chart(df, use_container_width=True)

        # Table
        st.subheader("Category Details")
        rows = []
        for cat in ALL_CATEGORIES:
            kg = emissions.get(cat, 0.0)
            pct = (kg / total_kg * 100) if total_kg > 0 else 0.0
            rows.append({"Category": cat, "Est. CO₂ (kg/year)": f"{kg:,.1f}", "Share": f"{pct:.1f} %"})
        st.table(rows)

        # Score explanation
        st.divider()
        st.subheader("ℹ️ How Is the Score Calculated?")
        st.info(SustainabilityScorer.get_score_explanation())


# ===========================================================================
# PAGE: AI Recommendations
# ===========================================================================
elif page == PAGE_RECOMMENDATIONS:
    st.title("💡 AI Climate Recommendations")
    st.markdown(
        "Based on your highest-emission categories, here are personalised actions "
        "you can take to reduce your estimated carbon footprint."
    )
    st.divider()

    if not st.session_state.emissions_calculated:
        st.info(
            "No results yet. Go to **📊 Enter My Data** and calculate your footprint first."
        )
    else:
        recommender = ClimateRecommender()
        recommendations = recommender.get_recommendations(st.session_state.emissions_dict)
        total_saving = ClimateRecommender.estimate_total_savings(recommendations)

        st.metric(
            "💚 Estimated Potential CO₂ Saving",
            f"Up to {total_saving:,.0f} kg/year",
            help="Rough estimate if you followed all recommendations below.",
        )
        st.caption(
            "⚠️ Savings are approximate estimates. Actual results depend on your specific situation."
        )
        st.divider()

        for i, rec in enumerate(recommendations, 1):
            with st.expander(f"**{i}. {rec.title}** — Category: {rec.category}", expanded=(i <= 3)):
                st.markdown(f"**What to do:** {rec.description}")
                st.markdown(f"**Why this matters for you:** _{rec.reason}_")
                if rec.saving_kg > 0:
                    st.success(
                        f"💚 Estimated saving: ~{rec.saving_kg:,.0f} kg CO₂/year"
                    )


# ===========================================================================
# PAGE: Sustainability Goals
# ===========================================================================
elif page == PAGE_GOALS:
    st.title("🎯 Sustainability Goals")
    st.markdown("Set a personal CO₂ reduction target and track your progress.")
    st.divider()

    if not st.session_state.emissions_calculated:
        st.info(
            "No footprint data yet. Go to **📊 Enter My Data** and calculate first."
        )
    else:
        total_kg = st.session_state.total_kg

        # Create / update goal
        st.subheader("Set a New Goal")
        with st.form("goal_form"):
            reduction_pct = st.slider(
                "Target CO₂ reduction (%)",
                min_value=5, max_value=50,
                value=20, step=5,
                help="How much do you want to reduce your estimated footprint?",
            )
            goal_submitted = st.form_submit_button("🎯 Set Goal", use_container_width=True)

        if goal_submitted:
            try:
                goal = GoalTracker.create_goal(total_kg, reduction_pct)
                st.session_state.goal = goal
                st.success(
                    f"✅ Goal set! Reduce from **{goal.baseline_kg:,.0f} kg** "
                    f"to **{goal.target_kg:,.0f} kg/year** "
                    f"({goal.reduction_percent} % reduction)."
                )
            except ValidationError as e:
                st.error(f"❌ {e}")

        # Show current goal
        st.divider()
        goal = st.session_state.goal
        if goal is None:
            st.info("You have not set a goal yet. Use the form above to create one.")
        else:
            st.subheader("📈 Your Current Goal")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Baseline", f"{goal.baseline_kg:,.0f} kg/year")
            with col2:
                st.metric("Target", f"{goal.target_kg:,.0f} kg/year")
            with col3:
                st.metric("Current", f"{goal.current_kg:,.0f} kg/year")

            progress = GoalTracker.get_progress_percent(goal)
            st.progress(
                min(int(progress), 100),
                text=f"Progress: {progress:.0f} % of goal achieved",
            )
            status = GoalTracker.get_status_message(goal)
            if GoalTracker.is_goal_met(goal):
                st.success(status)
            elif progress >= 50:
                st.warning(status)
            else:
                st.info(status)


# ===========================================================================
# PAGE: Climate Tips
# ===========================================================================
elif page == PAGE_TIPS:
    st.title("📚 Climate Action Tips")
    st.markdown(
        "Small changes add up. Here are some practical tips to reduce your "
        "environmental impact every day."
    )
    st.divider()

    # Show a random tip prominently
    tip_of_day = random.choice(CLIMATE_TIPS)
    st.success(f"**💚 Tip of the Day**\n\n{tip_of_day}")

    st.divider()
    st.subheader("All Tips")
    for tip in CLIMATE_TIPS:
        st.markdown(f"- {tip}")

    st.divider()
    st.subheader("📖 Learn More")
    st.markdown(
        """
        - [IPCC Climate Change Reports](https://www.ipcc.ch/reports/)
        - [UN Climate Action](https://www.un.org/en/climatechange/what-is-climate-change)
        - [Project Drawdown — Solutions](https://drawdown.org/solutions)
        - [Our World in Data — CO₂ Emissions](https://ourworldindata.org/co2-emissions)
        """
    )

"""
UserProfile — stores basic personal and lifestyle information.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Type


VALID_DIET_TYPES: list[str] = ["omnivore", "vegetarian", "vegan"]


@dataclass
class UserProfile:
    """
    Holds the user's personal and lifestyle data.

    All fields have safe defaults so the object can be created incrementally.
    """

    name: str = ""
    country: str = ""
    household_size: int = 1
    diet_type: str = "omnivore"

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dictionary for JSON storage."""
        return {
            "name": self.name,
            "country": self.country,
            "household_size": self.household_size,
            "diet_type": self.diet_type,
        }

    @classmethod
    def from_dict(cls: Type["UserProfile"], data: dict[str, Any]) -> "UserProfile":
        """Reconstruct a UserProfile from a plain dictionary."""
        return cls(
            name=str(data.get("name", "")),
            country=str(data.get("country", "")),
            household_size=int(data.get("household_size", 1)),
            diet_type=str(data.get("diet_type", "omnivore")),
        )

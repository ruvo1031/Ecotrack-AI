"""
EmissionData — stores all raw user consumption inputs.

All fields default to zero / False so the object can be built incrementally.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Type


VALID_FUEL_TYPES: list[str] = ["petrol", "diesel", "electric", "none"]


@dataclass
class EmissionData:
    """
    Holds every consumption value entered by the user.

    Units are documented on each field.
    All numeric fields default to 0; boolean fields default to False.
    """

    # ------------------------------------------------------------------
    # Electricity
    # ------------------------------------------------------------------
    electricity_kwh_per_month: float = 0.0
    """Monthly household electricity consumption in kWh."""

    uses_renewable_energy: bool = False
    """True if the household uses a 100 % renewable energy tariff."""

    # ------------------------------------------------------------------
    # Private vehicle
    # ------------------------------------------------------------------
    car_km_per_week: float = 0.0
    """Average kilometres driven per week."""

    fuel_type: str = "none"
    """Type of fuel: 'petrol', 'diesel', 'electric', or 'none' (no car)."""

    car_passengers: int = 1
    """Number of people sharing the journey (including the driver)."""

    # ------------------------------------------------------------------
    # Public transport
    # ------------------------------------------------------------------
    bus_km_per_week: float = 0.0
    """Kilometres travelled by bus per week."""

    train_km_per_week: float = 0.0
    """Kilometres travelled by train per week."""

    # ------------------------------------------------------------------
    # Air travel
    # ------------------------------------------------------------------
    short_flights_per_year: int = 0
    """Number of short-haul flights (under ~3 hours) per year."""

    long_flights_per_year: int = 0
    """Number of long-haul flights (over ~6 hours) per year."""

    # ------------------------------------------------------------------
    # Food
    # ------------------------------------------------------------------
    beef_meals_per_week: int = 0
    """Number of meals containing beef per week."""

    dairy_servings_per_day: int = 0
    """Number of dairy servings per day (milk, cheese, yoghurt, etc.)."""

    local_food_percent: int = 0
    """Estimated percentage of food that is locally sourced (0–100)."""

    # ------------------------------------------------------------------
    # Household waste
    # ------------------------------------------------------------------
    waste_kg_per_week: float = 0.0
    """Total household waste produced per week in kg."""

    recycling_percent: int = 0
    """Estimated percentage of waste that is recycled or composted (0–100)."""

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dictionary for JSON storage."""
        return {
            "electricity_kwh_per_month": self.electricity_kwh_per_month,
            "uses_renewable_energy": self.uses_renewable_energy,
            "car_km_per_week": self.car_km_per_week,
            "fuel_type": self.fuel_type,
            "car_passengers": self.car_passengers,
            "bus_km_per_week": self.bus_km_per_week,
            "train_km_per_week": self.train_km_per_week,
            "short_flights_per_year": self.short_flights_per_year,
            "long_flights_per_year": self.long_flights_per_year,
            "beef_meals_per_week": self.beef_meals_per_week,
            "dairy_servings_per_day": self.dairy_servings_per_day,
            "local_food_percent": self.local_food_percent,
            "waste_kg_per_week": self.waste_kg_per_week,
            "recycling_percent": self.recycling_percent,
        }

    @classmethod
    def from_dict(cls: Type["EmissionData"], data: dict[str, Any]) -> "EmissionData":
        """Reconstruct an EmissionData object from a plain dictionary."""
        return cls(
            electricity_kwh_per_month=float(data.get("electricity_kwh_per_month", 0.0)),
            uses_renewable_energy=bool(data.get("uses_renewable_energy", False)),
            car_km_per_week=float(data.get("car_km_per_week", 0.0)),
            fuel_type=str(data.get("fuel_type", "none")),
            car_passengers=int(data.get("car_passengers", 1)),
            bus_km_per_week=float(data.get("bus_km_per_week", 0.0)),
            train_km_per_week=float(data.get("train_km_per_week", 0.0)),
            short_flights_per_year=int(data.get("short_flights_per_year", 0)),
            long_flights_per_year=int(data.get("long_flights_per_year", 0)),
            beef_meals_per_week=int(data.get("beef_meals_per_week", 0)),
            dairy_servings_per_day=int(data.get("dairy_servings_per_day", 0)),
            local_food_percent=int(data.get("local_food_percent", 0)),
            waste_kg_per_week=float(data.get("waste_kg_per_week", 0.0)),
            recycling_percent=int(data.get("recycling_percent", 0)),
        )

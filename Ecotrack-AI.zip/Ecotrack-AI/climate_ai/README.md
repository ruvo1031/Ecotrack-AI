# AI for Climate Action & Sustainability

An educational, beginner-friendly Streamlit application that helps users understand
their personal carbon footprint and take practical climate action.

## Install dependencies

```bash
pip install -r requirements.txt
```

## Run the app

```bash
streamlit run app.py
```

## Run tests

```bash
pytest tests/ -v
```

> **Disclaimer:** All carbon footprint calculations are **estimates** based on simplified
> emission factors. They are intended for educational purposes only and are not
> scientifically precise measurements.

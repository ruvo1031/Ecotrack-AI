"""
test_goal_tracker.py — unit tests for GoalTracker and SustainabilityGoal.
"""
import pytest
from core.goal_tracker import GoalTracker, SustainabilityGoal
from utils.exceptions import ValidationError


# ---------------------------------------------------------------------------
# create_goal
# ---------------------------------------------------------------------------

def test_create_goal_basic():
    goal = GoalTracker.create_goal(baseline_kg=5000.0, reduction_percent=20)
    assert goal.baseline_kg == 5000.0
    assert goal.reduction_percent == 20
    assert goal.target_kg == pytest.approx(4000.0, rel=1e-3)
    assert goal.current_kg == 5000.0


def test_create_goal_target_formula():
    """target = baseline × (1 − pct/100)."""
    goal = GoalTracker.create_goal(1000.0, 30)
    assert goal.target_kg == pytest.approx(700.0, rel=1e-3)


def test_create_goal_minimum_percent():
    goal = GoalTracker.create_goal(1000.0, 5)
    assert goal.target_kg == pytest.approx(950.0, rel=1e-3)


def test_create_goal_maximum_percent():
    goal = GoalTracker.create_goal(1000.0, 50)
    assert goal.target_kg == pytest.approx(500.0, rel=1e-3)


def test_create_goal_rejects_below_minimum():
    with pytest.raises(ValidationError):
        GoalTracker.create_goal(1000.0, 4)


def test_create_goal_rejects_above_maximum():
    with pytest.raises(ValidationError):
        GoalTracker.create_goal(1000.0, 51)


def test_create_goal_zero_baseline():
    goal = GoalTracker.create_goal(0.0, 20)
    assert goal.target_kg == 0.0


# ---------------------------------------------------------------------------
# update_progress
# ---------------------------------------------------------------------------

def test_update_progress_updates_current_kg():
    goal = GoalTracker.create_goal(5000.0, 20)
    updated = GoalTracker.update_progress(goal, 3500.0)
    assert updated.current_kg == pytest.approx(3500.0)


def test_update_progress_preserves_baseline_and_target():
    goal = GoalTracker.create_goal(5000.0, 20)
    updated = GoalTracker.update_progress(goal, 3500.0)
    assert updated.baseline_kg == 5000.0
    assert updated.target_kg == pytest.approx(4000.0)


def test_update_progress_clamps_negative():
    goal = GoalTracker.create_goal(5000.0, 20)
    updated = GoalTracker.update_progress(goal, -100.0)
    assert updated.current_kg == 0.0


# ---------------------------------------------------------------------------
# get_progress_percent
# ---------------------------------------------------------------------------

def test_progress_zero_at_start():
    goal = GoalTracker.create_goal(5000.0, 20)
    # current = baseline at creation, so 0 % progress
    assert GoalTracker.get_progress_percent(goal) == pytest.approx(0.0)


def test_progress_100_when_target_met():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_at_target = GoalTracker.update_progress(goal, 4000.0)
    assert GoalTracker.get_progress_percent(goal_at_target) == pytest.approx(100.0)


def test_progress_50_percent():
    goal = GoalTracker.create_goal(5000.0, 20)  # need to go from 5000 → 4000 (save 1000)
    goal_halfway = GoalTracker.update_progress(goal, 4500.0)  # saved 500 of 1000
    assert GoalTracker.get_progress_percent(goal_halfway) == pytest.approx(50.0)


def test_progress_clamped_at_100():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_exceeded = GoalTracker.update_progress(goal, 2000.0)  # went further than target
    assert GoalTracker.get_progress_percent(goal_exceeded) == pytest.approx(100.0)


def test_progress_clamped_at_zero_if_worsened():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_worse = GoalTracker.update_progress(goal, 6000.0)
    assert GoalTracker.get_progress_percent(goal_worse) == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# is_goal_met
# ---------------------------------------------------------------------------

def test_goal_met_when_at_target():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_met = GoalTracker.update_progress(goal, 4000.0)
    assert GoalTracker.is_goal_met(goal_met) is True


def test_goal_met_when_below_target():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_below = GoalTracker.update_progress(goal, 3000.0)
    assert GoalTracker.is_goal_met(goal_below) is True


def test_goal_not_met_when_above_target():
    goal = GoalTracker.create_goal(5000.0, 20)
    goal_partial = GoalTracker.update_progress(goal, 4500.0)
    assert GoalTracker.is_goal_met(goal_partial) is False


# ---------------------------------------------------------------------------
# Serialisation round-trip
# ---------------------------------------------------------------------------

def test_goal_serialises_and_deserialises():
    original = GoalTracker.create_goal(6000.0, 25)
    restored = SustainabilityGoal.from_dict(original.to_dict())
    assert restored.baseline_kg == original.baseline_kg
    assert restored.reduction_percent == original.reduction_percent
    assert restored.target_kg == pytest.approx(original.target_kg)
    assert restored.current_kg == pytest.approx(original.current_kg)

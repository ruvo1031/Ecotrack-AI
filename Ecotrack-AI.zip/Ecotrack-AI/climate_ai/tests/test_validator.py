"""
test_validator.py — unit tests for InputValidator.
"""
import pytest
from utils.validator import InputValidator
from utils.exceptions import ValidationError


# ---------------------------------------------------------------------------
# validate_non_negative
# ---------------------------------------------------------------------------

def test_non_negative_passes_for_zero():
    InputValidator.validate_non_negative(0.0, "field")  # should not raise


def test_non_negative_passes_for_positive():
    InputValidator.validate_non_negative(100.0, "field")


def test_non_negative_fails_for_negative():
    with pytest.raises(ValidationError, match="field"):
        InputValidator.validate_non_negative(-1.0, "field")


# ---------------------------------------------------------------------------
# validate_range
# ---------------------------------------------------------------------------

def test_range_passes_at_boundaries():
    InputValidator.validate_range(0, 0, 100, "field")
    InputValidator.validate_range(100, 0, 100, "field")
    InputValidator.validate_range(50, 0, 100, "field")


def test_range_fails_below_min():
    with pytest.raises(ValidationError):
        InputValidator.validate_range(-1, 0, 100, "field")


def test_range_fails_above_max():
    with pytest.raises(ValidationError):
        InputValidator.validate_range(101, 0, 100, "field")


# ---------------------------------------------------------------------------
# validate_choice
# ---------------------------------------------------------------------------

def test_choice_passes_for_valid_value():
    InputValidator.validate_choice("petrol", ["petrol", "diesel", "electric", "none"], "fuel")


def test_choice_fails_for_invalid_value():
    with pytest.raises(ValidationError, match="fuel"):
        InputValidator.validate_choice("hydrogen", ["petrol", "diesel"], "fuel")


# ---------------------------------------------------------------------------
# validate_required
# ---------------------------------------------------------------------------

def test_required_passes_for_non_empty():
    InputValidator.validate_required("Alice", "name")


def test_required_fails_for_empty_string():
    with pytest.raises(ValidationError, match="name"):
        InputValidator.validate_required("", "name")


def test_required_fails_for_whitespace_only():
    with pytest.raises(ValidationError):
        InputValidator.validate_required("   ", "name")


# ---------------------------------------------------------------------------
# validate_user_profile
# ---------------------------------------------------------------------------

def test_profile_valid():
    InputValidator.validate_user_profile("Alice", 2, "omnivore")


def test_profile_empty_name():
    with pytest.raises(ValidationError):
        InputValidator.validate_user_profile("", 2, "omnivore")


def test_profile_household_too_large():
    with pytest.raises(ValidationError):
        InputValidator.validate_user_profile("Alice", 21, "omnivore")


def test_profile_invalid_diet():
    with pytest.raises(ValidationError):
        InputValidator.validate_user_profile("Alice", 1, "carnivore")


# ---------------------------------------------------------------------------
# validate_emission_data
# ---------------------------------------------------------------------------

def _valid_emission_kwargs() -> dict:
    return dict(
        electricity_kwh_per_month=200.0,
        car_km_per_week=100.0,
        fuel_type="petrol",
        car_passengers=1,
        bus_km_per_week=20.0,
        train_km_per_week=10.0,
        short_flights_per_year=2,
        long_flights_per_year=1,
        beef_meals_per_week=3,
        dairy_servings_per_day=2,
        local_food_percent=20,
        waste_kg_per_week=5.0,
        recycling_percent=30,
    )


def test_emission_data_valid():
    InputValidator.validate_emission_data(**_valid_emission_kwargs())


def test_emission_data_negative_electricity():
    kwargs = _valid_emission_kwargs()
    kwargs["electricity_kwh_per_month"] = -10.0
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_electricity_too_high():
    kwargs = _valid_emission_kwargs()
    kwargs["electricity_kwh_per_month"] = 15_000.0
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_invalid_fuel_type():
    kwargs = _valid_emission_kwargs()
    kwargs["fuel_type"] = "hydrogen"
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_driving_with_no_fuel_type():
    """Car distance set but fuel_type='none' should raise a logical error."""
    kwargs = _valid_emission_kwargs()
    kwargs["fuel_type"] = "none"
    kwargs["car_km_per_week"] = 100.0
    with pytest.raises(ValidationError, match="fuel type"):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_recycling_above_100():
    kwargs = _valid_emission_kwargs()
    kwargs["recycling_percent"] = 110
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_negative_waste():
    kwargs = _valid_emission_kwargs()
    kwargs["waste_kg_per_week"] = -5.0
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_too_many_short_flights():
    kwargs = _valid_emission_kwargs()
    kwargs["short_flights_per_year"] = 100
    with pytest.raises(ValidationError):
        InputValidator.validate_emission_data(**kwargs)


def test_emission_data_zero_all_fields():
    """All zeros with fuel_type='none' should pass validation."""
    InputValidator.validate_emission_data(
        electricity_kwh_per_month=0.0,
        car_km_per_week=0.0,
        fuel_type="none",
        car_passengers=1,
        bus_km_per_week=0.0,
        train_km_per_week=0.0,
        short_flights_per_year=0,
        long_flights_per_year=0,
        beef_meals_per_week=0,
        dairy_servings_per_day=0,
        local_food_percent=0,
        waste_kg_per_week=0.0,
        recycling_percent=0,
    )


# ---------------------------------------------------------------------------
# validate_goal
# ---------------------------------------------------------------------------

def test_goal_valid_boundaries():
    InputValidator.validate_goal(5)
    InputValidator.validate_goal(50)
    InputValidator.validate_goal(20)


def test_goal_rejects_below_5():
    with pytest.raises(ValidationError):
        InputValidator.validate_goal(4)


def test_goal_rejects_above_50():
    with pytest.raises(ValidationError):
        InputValidator.validate_goal(51)

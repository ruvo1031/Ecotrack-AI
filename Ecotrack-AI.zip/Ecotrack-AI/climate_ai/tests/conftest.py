"""
conftest.py — shared pytest fixtures for the Climate AI test suite.
"""
import sys
import os

# Ensure imports work from the climate_ai package root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from models.user_profile import UserProfile
from models.emission_data import EmissionData


@pytest.fixture
def default_profile() -> UserProfile:
    """A standard omnivore household-of-one profile."""
    return UserProfile(name="Test User", country="UK", household_size=1, diet_type="omnivore")


@pytest.fixture
def vegetarian_profile() -> UserProfile:
    return UserProfile(name="Test User", country="UK", household_size=1, diet_type="vegetarian")


@pytest.fixture
def vegan_profile() -> UserProfile:
    return UserProfile(name="Test User", country="UK", household_size=1, diet_type="vegan")


@pytest.fixture
def default_emission_data() -> EmissionData:
    """Emission data with realistic mid-range values."""
    return EmissionData(
        electricity_kwh_per_month=200.0,
        uses_renewable_energy=False,
        car_km_per_week=100.0,
        fuel_type="petrol",
        car_passengers=1,
        bus_km_per_week=20.0,
        train_km_per_week=10.0,
        short_flights_per_year=2,
        long_flights_per_year=1,
        beef_meals_per_week=3,
        dairy_servings_per_day=2,
        local_food_percent=20,
        waste_kg_per_week=5.0,
        recycling_percent=30,
    )


@pytest.fixture
def zero_emission_data() -> EmissionData:
    """Emission data where every field is zero / off."""
    return EmissionData()

"""
test_recommender.py — unit tests for ClimateRecommender.
"""
import pytest
from core.recommender import ClimateRecommender, Recommendation
from core.calculator import (
    CATEGORY_ELECTRICITY, CATEGORY_VEHICLE, CATEGORY_FLIGHTS,
    CATEGORY_FOOD, CATEGORY_WASTE, CATEGORY_TRANSPORT,
)


@pytest.fixture
def high_flight_emissions() -> dict[str, float]:
    return {
        CATEGORY_ELECTRICITY: 400.0,
        CATEGORY_VEHICLE: 500.0,
        CATEGORY_TRANSPORT: 50.0,
        CATEGORY_FLIGHTS: 3_500.0,
        CATEGORY_FOOD: 1_200.0,
        CATEGORY_WASTE: 80.0,
    }


@pytest.fixture
def high_food_emissions() -> dict[str, float]:
    return {
        CATEGORY_ELECTRICITY: 100.0,
        CATEGORY_VEHICLE: 0.0,
        CATEGORY_TRANSPORT: 0.0,
        CATEGORY_FLIGHTS: 0.0,
        CATEGORY_FOOD: 4_000.0,
        CATEGORY_WASTE: 50.0,
    }


@pytest.fixture
def all_zero_emissions() -> dict[str, float]:
    return {cat: 0.0 for cat in [
        CATEGORY_ELECTRICITY, CATEGORY_VEHICLE, CATEGORY_TRANSPORT,
        CATEGORY_FLIGHTS, CATEGORY_FOOD, CATEGORY_WASTE,
    ]}


# ---------------------------------------------------------------------------
# get_top_categories
# ---------------------------------------------------------------------------

def test_top_categories_returns_highest_first(high_flight_emissions):
    recommender = ClimateRecommender(top_n=3)
    top = recommender.get_top_categories(high_flight_emissions)
    assert top[0] == CATEGORY_FLIGHTS


def test_top_categories_excludes_zeros():
    emissions = {CATEGORY_FLIGHTS: 3000.0, CATEGORY_VEHICLE: 0.0, CATEGORY_FOOD: 1200.0}
    recommender = ClimateRecommender()
    top = recommender.get_top_categories(emissions)
    assert CATEGORY_VEHICLE not in top


def test_top_categories_respects_n(high_flight_emissions):
    recommender = ClimateRecommender(top_n=2)
    top = recommender.get_top_categories(high_flight_emissions)
    assert len(top) <= 2


def test_top_categories_empty_when_all_zero(all_zero_emissions):
    recommender = ClimateRecommender()
    top = recommender.get_top_categories(all_zero_emissions)
    assert top == []


# ---------------------------------------------------------------------------
# get_recommendations
# ---------------------------------------------------------------------------

def test_recommendations_returned_for_top_categories(high_flight_emissions):
    recommender = ClimateRecommender(top_n=3, actions_per_category=2)
    recs = recommender.get_recommendations(high_flight_emissions)
    assert len(recs) > 0
    assert all(isinstance(r, Recommendation) for r in recs)


def test_recommendations_include_flight_category(high_flight_emissions):
    recs = ClimateRecommender().get_recommendations(high_flight_emissions)
    categories = [r.category for r in recs]
    assert CATEGORY_FLIGHTS in categories


def test_recommendations_have_non_empty_fields(high_flight_emissions):
    recs = ClimateRecommender().get_recommendations(high_flight_emissions)
    for r in recs:
        assert r.title
        assert r.description
        assert r.reason
        assert r.category


def test_recommendations_reason_contains_kg_value(high_flight_emissions):
    """The reason text should mention a numeric value from the user's data."""
    recs = ClimateRecommender().get_recommendations(high_flight_emissions)
    flight_recs = [r for r in recs if r.category == CATEGORY_FLIGHTS]
    assert any("3500" in r.reason or "3,500" in r.reason for r in flight_recs)


def test_general_tips_returned_when_all_zero(all_zero_emissions):
    """When all categories are zero, general tips should be returned."""
    recs = ClimateRecommender().get_recommendations(all_zero_emissions)
    assert len(recs) > 0
    assert all(r.category == "General" for r in recs)


def test_max_recommendations_per_category(high_flight_emissions):
    """Actions per category should not exceed the configured limit."""
    recommender = ClimateRecommender(top_n=3, actions_per_category=1)
    recs = recommender.get_recommendations(high_flight_emissions)
    from collections import Counter
    counts = Counter(r.category for r in recs)
    for count in counts.values():
        assert count <= 1


# ---------------------------------------------------------------------------
# estimate_total_savings
# ---------------------------------------------------------------------------

def test_total_savings_sums_correctly():
    recs = [
        Recommendation("A", "t", "d", "r", saving_kg=100),
        Recommendation("B", "t", "d", "r", saving_kg=200),
        Recommendation("C", "t", "d", "r", saving_kg=50),
    ]
    assert ClimateRecommender.estimate_total_savings(recs) == pytest.approx(350.0)


def test_total_savings_zero_for_general_tips(all_zero_emissions):
    recs = ClimateRecommender().get_recommendations(all_zero_emissions)
    assert ClimateRecommender.estimate_total_savings(recs) == 0.0

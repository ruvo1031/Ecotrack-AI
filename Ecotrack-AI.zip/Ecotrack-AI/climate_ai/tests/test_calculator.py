"""
test_calculator.py — unit tests for FootprintCalculator.
"""
import pytest
from models.user_profile import UserProfile
from models.emission_data import EmissionData
from core.calculator import FootprintCalculator, ALL_CATEGORIES
from core.emission_factors import FACTORS


# ---------------------------------------------------------------------------
# Electricity
# ---------------------------------------------------------------------------

def test_electricity_grid(default_profile, default_emission_data):
    """200 kWh/month × 12 × 0.40 / 1 person = 960 kg."""
    calc = FootprintCalculator(default_emission_data, default_profile)
    result = calc.calc_electricity_emissions()
    assert result == pytest.approx(960.0, rel=1e-3)


def test_electricity_renewable(default_profile):
    """Renewable tariff should use the lower factor (0.05)."""
    data = EmissionData(electricity_kwh_per_month=200.0, uses_renewable_energy=True)
    calc = FootprintCalculator(data, default_profile)
    expected = 200.0 * 12 * 0.05
    assert calc.calc_electricity_emissions() == pytest.approx(expected, rel=1e-3)


def test_electricity_split_by_household(default_emission_data):
    """Household of 4 should divide electricity emissions by 4."""
    profile = UserProfile(name="A", household_size=4, diet_type="omnivore")
    calc_single = FootprintCalculator(default_emission_data, UserProfile(name="A", household_size=1, diet_type="omnivore"))
    calc_four = FootprintCalculator(default_emission_data, profile)
    assert calc_four.calc_electricity_emissions() == pytest.approx(
        calc_single.calc_electricity_emissions() / 4, rel=1e-3
    )


def test_electricity_zero(default_profile):
    """Zero kWh should produce zero emissions."""
    data = EmissionData(electricity_kwh_per_month=0.0)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_electricity_emissions() == 0.0


# ---------------------------------------------------------------------------
# Vehicle / Fuel
# ---------------------------------------------------------------------------

def test_vehicle_petrol(default_profile):
    """100 km/week × 52 × 0.21 / 1 = 1092 kg."""
    data = EmissionData(car_km_per_week=100.0, fuel_type="petrol", car_passengers=1)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_vehicle_emissions() == pytest.approx(1092.0, rel=1e-3)


def test_vehicle_diesel(default_profile):
    """100 km/week × 52 × 0.17 / 1 = 884 kg."""
    data = EmissionData(car_km_per_week=100.0, fuel_type="diesel", car_passengers=1)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_vehicle_emissions() == pytest.approx(884.0, rel=1e-3)


def test_vehicle_electric(default_profile):
    """Electric car should use the lower 0.05 factor."""
    data = EmissionData(car_km_per_week=100.0, fuel_type="electric", car_passengers=1)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_vehicle_emissions() == pytest.approx(100.0 * 52 * 0.05, rel=1e-3)


def test_vehicle_no_car(default_profile):
    """fuel_type='none' should return 0 regardless of km."""
    data = EmissionData(car_km_per_week=100.0, fuel_type="none")
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_vehicle_emissions() == 0.0


def test_vehicle_carpooling_halves_emissions(default_profile):
    """2 passengers should halve per-person emissions."""
    data_solo = EmissionData(car_km_per_week=100.0, fuel_type="petrol", car_passengers=1)
    data_pool = EmissionData(car_km_per_week=100.0, fuel_type="petrol", car_passengers=2)
    calc_solo = FootprintCalculator(data_solo, default_profile)
    calc_pool = FootprintCalculator(data_pool, default_profile)
    assert calc_pool.calc_vehicle_emissions() == pytest.approx(
        calc_solo.calc_vehicle_emissions() / 2, rel=1e-3
    )


def test_vehicle_zero_km(default_profile):
    """Zero km should produce zero emissions even with a fuel type set."""
    data = EmissionData(car_km_per_week=0.0, fuel_type="petrol")
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_vehicle_emissions() == 0.0


# ---------------------------------------------------------------------------
# Public transport
# ---------------------------------------------------------------------------

def test_transport_bus_and_train(default_profile):
    """20 km bus/week + 10 km train/week."""
    data = EmissionData(bus_km_per_week=20.0, train_km_per_week=10.0)
    calc = FootprintCalculator(data, default_profile)
    expected = (20.0 * 52 * FACTORS.bus_km) + (10.0 * 52 * FACTORS.train_km)
    assert calc.calc_transport_emissions() == pytest.approx(expected, rel=1e-3)


def test_transport_zero(default_profile, zero_emission_data):
    assert FootprintCalculator(zero_emission_data, default_profile).calc_transport_emissions() == 0.0


# ---------------------------------------------------------------------------
# Flights
# ---------------------------------------------------------------------------

def test_flights_short_and_long(default_profile):
    """2 short + 1 long flight."""
    data = EmissionData(short_flights_per_year=2, long_flights_per_year=1)
    calc = FootprintCalculator(data, default_profile)
    expected = 2 * FACTORS.short_flight_kg + 1 * FACTORS.long_flight_kg
    assert calc.calc_flight_emissions() == pytest.approx(expected, rel=1e-3)


def test_flights_zero(default_profile, zero_emission_data):
    assert FootprintCalculator(zero_emission_data, default_profile).calc_flight_emissions() == 0.0


def test_flights_only_long(default_profile):
    data = EmissionData(long_flights_per_year=3)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_flight_emissions() == pytest.approx(3 * FACTORS.long_flight_kg, rel=1e-3)


# ---------------------------------------------------------------------------
# Food
# ---------------------------------------------------------------------------

def test_food_omnivore_baseline(default_profile):
    """Zero beef/dairy → just the omnivore base diet."""
    data = EmissionData(beef_meals_per_week=0, dairy_servings_per_day=0, local_food_percent=0)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_food_emissions() == pytest.approx(FACTORS.diet_base_omnivore_year, rel=1e-3)


def test_food_vegan_lower_than_omnivore(vegan_profile, default_profile):
    """Vegan diet base should be lower than omnivore."""
    data = EmissionData(beef_meals_per_week=0, dairy_servings_per_day=0)
    calc_vegan = FootprintCalculator(data, vegan_profile)
    calc_omni = FootprintCalculator(data, default_profile)
    assert calc_vegan.calc_food_emissions() < calc_omni.calc_food_emissions()


def test_food_beef_adds_emissions(default_profile):
    """More beef meals should increase food emissions."""
    data_low = EmissionData(beef_meals_per_week=1)
    data_high = EmissionData(beef_meals_per_week=5)
    calc_low = FootprintCalculator(data_low, default_profile)
    calc_high = FootprintCalculator(data_high, default_profile)
    assert calc_high.calc_food_emissions() > calc_low.calc_food_emissions()


def test_food_local_reduces_emissions(default_profile):
    """Higher local food percentage should reduce food emissions."""
    data_low = EmissionData(local_food_percent=10)
    data_high = EmissionData(local_food_percent=90)
    calc_low = FootprintCalculator(data_low, default_profile)
    calc_high = FootprintCalculator(data_high, default_profile)
    assert calc_high.calc_food_emissions() < calc_low.calc_food_emissions()


# ---------------------------------------------------------------------------
# Waste
# ---------------------------------------------------------------------------

def test_waste_basic(default_profile):
    """5 kg/week, 30 % recycled."""
    data = EmissionData(waste_kg_per_week=5.0, recycling_percent=30)
    calc = FootprintCalculator(data, default_profile)
    expected = 5.0 * 52 * 0.70 * FACTORS.waste_kg_co2_per_kg
    assert calc.calc_waste_emissions() == pytest.approx(expected, rel=1e-3)


def test_waste_full_recycling(default_profile):
    """100 % recycling should produce near-zero waste emissions."""
    data = EmissionData(waste_kg_per_week=10.0, recycling_percent=100)
    calc = FootprintCalculator(data, default_profile)
    assert calc.calc_waste_emissions() == pytest.approx(0.0, abs=0.01)


def test_waste_zero(default_profile, zero_emission_data):
    assert FootprintCalculator(zero_emission_data, default_profile).calc_waste_emissions() == 0.0


# ---------------------------------------------------------------------------
# Total and category dict
# ---------------------------------------------------------------------------

def test_calc_total_equals_sum(default_profile, default_emission_data):
    """calc_total() should equal the sum of calc_all() values."""
    calc = FootprintCalculator(default_emission_data, default_profile)
    total = calc.calc_total()
    summed = round(sum(calc.calc_all().values()), 2)
    assert total == summed


def test_calc_all_returns_all_categories(default_profile, default_emission_data):
    """calc_all() must return a value for every defined category."""
    calc = FootprintCalculator(default_emission_data, default_profile)
    result = calc.calc_all()
    for cat in ALL_CATEGORIES:
        assert cat in result
        assert result[cat] >= 0.0


def test_calc_total_zero_for_zero_data(default_profile, zero_emission_data):
    """With all-zero inputs the food baseline still produces some emission."""
    calc = FootprintCalculator(zero_emission_data, default_profile)
    # Food baseline for omnivore is > 0 even with zero inputs
    assert calc.calc_total() > 0.0


# ---------------------------------------------------------------------------
# Highest category
# ---------------------------------------------------------------------------

def test_highest_category_is_flights_when_many_flights(default_profile):
    """Many long-haul flights should dominate."""
    data = EmissionData(long_flights_per_year=10)
    calc = FootprintCalculator(data, default_profile)
    assert calc.get_highest_category() == "Air Travel"


def test_highest_category_none_when_all_zero(default_profile):
    """When all non-food categories are zero the highest should be Food."""
    calc = FootprintCalculator(EmissionData(), default_profile)
    # Food has a non-zero baseline, so highest should be Food
    assert calc.get_highest_category() == "Food"

"""
test_scorer.py — unit tests for SustainabilityScorer.
"""
import pytest
from core.scorer import SustainabilityScorer, GLOBAL_AVERAGE_KG, MAX_BAD_KG


def test_score_zero_footprint():
    """Zero kg should return a perfect score of 100."""
    assert SustainabilityScorer.calculate_score(0.0) == 100


def test_score_negative_footprint():
    """Negative values are treated the same as zero."""
    assert SustainabilityScorer.calculate_score(-100.0) == 100


def test_score_at_global_average():
    """Score at the global average (~4000 kg) should be around 80."""
    score = SustainabilityScorer.calculate_score(GLOBAL_AVERAGE_KG)
    assert 75 <= score <= 85  # roughly 80


def test_score_at_max_bad():
    """Score at MAX_BAD_KG should be 0."""
    assert SustainabilityScorer.calculate_score(MAX_BAD_KG) == 0


def test_score_above_max_bad():
    """Score above MAX_BAD_KG must be clamped to 0."""
    assert SustainabilityScorer.calculate_score(MAX_BAD_KG + 5000) == 0


def test_score_between_zero_and_100():
    """Score must always be in [0, 100] for any input."""
    for kg in [0, 500, 1000, 4000, 8000, 15000, 25000]:
        score = SustainabilityScorer.calculate_score(float(kg))
        assert 0 <= score <= 100


def test_score_decreases_as_footprint_increases():
    """Higher footprint should always produce equal or lower score."""
    scores = [SustainabilityScorer.calculate_score(float(kg)) for kg in range(0, 20001, 1000)]
    for i in range(len(scores) - 1):
        assert scores[i] >= scores[i + 1]


# --- Label tests ---

def test_label_excellent():
    assert SustainabilityScorer.get_label(90) == "Excellent"


def test_label_good():
    assert SustainabilityScorer.get_label(65) == "Good"


def test_label_fair():
    assert SustainabilityScorer.get_label(50) == "Fair"


def test_label_poor():
    assert SustainabilityScorer.get_label(20) == "Poor"


def test_label_boundaries():
    assert SustainabilityScorer.get_label(80) == "Excellent"
    assert SustainabilityScorer.get_label(79) == "Good"
    assert SustainabilityScorer.get_label(60) == "Good"
    assert SustainabilityScorer.get_label(59) == "Fair"
    assert SustainabilityScorer.get_label(40) == "Fair"
    assert SustainabilityScorer.get_label(39) == "Poor"
    assert SustainabilityScorer.get_label(0) == "Poor"


# --- Comparison message ---

def test_comparison_message_below_average():
    msg = SustainabilityScorer.get_comparison_message(2000.0)
    assert "below" in msg.lower()


def test_comparison_message_above_average():
    msg = SustainabilityScorer.get_comparison_message(8000.0)
    assert "above" in msg.lower()


def test_comparison_message_zero():
    msg = SustainabilityScorer.get_comparison_message(0.0)
    assert "zero" in msg.lower() or "outstanding" in msg.lower()

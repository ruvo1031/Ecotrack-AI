"""
SustainabilityScorer — converts an estimated total carbon footprint
into a human-readable 0–100 sustainability score.

How the score works
-------------------
We use a simple linear scale anchored at two points:
  • 0 kg/year  → score 100  (zero footprint = perfect)
  • 20 000 kg/year → score 0   (very high footprint = worst)

Score formula:
    raw   = (MAX_BAD_KG - total_kg) / MAX_BAD_KG
    score = clamp(int(raw × 100), 0, 100)

The global average is ~4 000 kg/year (World Bank reference).
A score of 80 therefore corresponds to roughly 4 000 kg.

This is intentionally simple and educational — not a certified metric.
"""


# Reference constants
GLOBAL_AVERAGE_KG: float = 4_000.0   # approximate world average annual footprint
MAX_BAD_KG: float = 20_000.0         # anything at or above this scores 0

SCORE_LABELS: dict[str, tuple[int, int]] = {
    "Excellent": (80, 100),
    "Good":      (60, 79),
    "Fair":      (40, 59),
    "Poor":      (0,  39),
}


class SustainabilityScorer:
    """
    Converts a total estimated CO₂ footprint (kg/year) into a 0–100 score.

    A higher score means a lower (better) estimated carbon footprint.
    """

    # ------------------------------------------------------------------
    # Core calculation
    # ------------------------------------------------------------------

    @staticmethod
    def calculate_score(total_kg: float) -> int:
        """
        Convert a total estimated footprint to a 0–100 sustainability score.

        Args:
            total_kg: Total annual estimated CO₂ in kg.

        Returns:
            Integer score in range [0, 100].
        """
        if total_kg <= 0:
            return 100
        raw = (MAX_BAD_KG - total_kg) / MAX_BAD_KG
        return max(0, min(100, int(raw * 100)))

    # ------------------------------------------------------------------
    # Labels and messages
    # ------------------------------------------------------------------

    @staticmethod
    def get_label(score: int) -> str:
        """
        Return a text label for the score band.

        Returns one of: 'Excellent', 'Good', 'Fair', 'Poor'.
        """
        for label, (low, high) in SCORE_LABELS.items():
            if low <= score <= high:
                return label
        return "Poor"

    @staticmethod
    def get_comparison_message(total_kg: float) -> str:
        """
        Return a friendly sentence comparing the user's footprint
        to the global average.
        """
        if total_kg <= 0:
            return "Your estimated footprint is effectively zero — outstanding!"
        diff = total_kg - GLOBAL_AVERAGE_KG
        if abs(diff) < 200:
            return (
                f"Your estimated footprint ({total_kg:,.0f} kg CO₂/year) is "
                "roughly equal to the global average of ~4,000 kg/year."
            )
        elif diff < 0:
            below = abs(diff)
            return (
                f"Your estimated footprint ({total_kg:,.0f} kg CO₂/year) is "
                f"{below:,.0f} kg below the global average of ~4,000 kg/year. "
                "Well done!"
            )
        else:
            return (
                f"Your estimated footprint ({total_kg:,.0f} kg CO₂/year) is "
                f"{diff:,.0f} kg above the global average of ~4,000 kg/year. "
                "There is room to improve."
            )

    @staticmethod
    def get_score_explanation() -> str:
        """Return a plain-English explanation of how the score is calculated."""
        return (
            "The sustainability score (0–100) is calculated from your estimated "
            "total CO₂ footprint. A footprint of 0 kg scores 100; a footprint of "
            "20,000 kg or above scores 0. The global average is approximately "
            "4,000 kg/year. A score above 80 is excellent; 60–79 is good; "
            "40–59 is fair; below 40 needs attention."
        )

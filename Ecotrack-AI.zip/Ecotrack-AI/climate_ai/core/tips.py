"""
tips.py — A collection of rotating climate-friendly tips shown on the dashboard.
"""

CLIMATE_TIPS: list[str] = [
    "🌱 Planting trees absorbs CO₂ — even one tree planted per year helps.",
    "💡 Turning off lights and unplugging devices saves both energy and money.",
    "🚲 Cycling or walking instead of driving for short trips produces zero emissions.",
    "🥦 Eating plant-based meals even two days a week can cut food emissions by 20 %.",
    "♻️ Recycling aluminium uses 95 % less energy than producing it from raw materials.",
    "🌊 Shorter showers reduce both water use and the energy needed to heat water.",
    "🛍️ Using reusable bags and bottles reduces plastic waste and packaging emissions.",
    "🏠 Improving home insulation can cut heating emissions by up to 30 %.",
    "✈️ One less long-haul flight per year can save up to 1,600 kg of CO₂.",
    "🌞 Solar panels on a typical home can offset 1–2 tonnes of CO₂ per year.",
    "🥩 Beef produces up to 20× more CO₂ per kg than plant proteins like lentils.",
    "🔋 Charging electric vehicles overnight using off-peak electricity is greener.",
    "🍎 Buying local and seasonal produce reduces food transport emissions.",
    "🌡️ Lowering your home thermostat by 1 °C can reduce heating bills by 10 %.",
    "📦 Choosing products with minimal packaging reduces both waste and emissions.",
]

"""
Emission factors used to estimate CO₂ emissions in each category.

All values are in kg CO₂ equivalent per unit of consumption.
These are simplified, approximate values intended for educational use only.
They are NOT scientifically precise — actual emissions vary by region,
technology, and individual behaviour.

Sources: approximate values drawn from publicly available averages
(e.g. UK DEFRA, IEA, IPCC AR6 reports).
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class EmissionFactors:
    """
    A frozen dataclass holding all CO₂ emission constants.

    Frozen means the values cannot be changed at runtime,
    making this a safe single source of truth.
    """

    # ------------------------------------------------------------------
    # Electricity  (kg CO₂ per kWh)
    # ------------------------------------------------------------------
    electricity_grid_kwh: float = 0.40
    """Average grid electricity — global average."""

    electricity_renewable_kwh: float = 0.05
    """Renewable energy — residual lifecycle emissions (panels, wind turbines, etc.)."""

    # ------------------------------------------------------------------
    # Private vehicle  (kg CO₂ per km driven)
    # ------------------------------------------------------------------
    vehicle_petrol_km: float = 0.21
    """Petrol / gasoline car."""

    vehicle_diesel_km: float = 0.17
    """Diesel car."""

    vehicle_electric_km: float = 0.05
    """Electric car — based on average grid electricity for charging."""

    # ------------------------------------------------------------------
    # Public transport  (kg CO₂ per km)
    # ------------------------------------------------------------------
    bus_km: float = 0.089
    """Average bus passenger."""

    train_km: float = 0.041
    """Average train passenger."""

    # ------------------------------------------------------------------
    # Air travel  (kg CO₂ per flight — round-trip averages)
    # ------------------------------------------------------------------
    short_flight_kg: float = 255.0
    """Short-haul flight (under ~3 hours, ~800 km round-trip)."""

    long_flight_kg: float = 1620.0
    """Long-haul flight (over ~6 hours, ~10 000 km round-trip)."""

    # ------------------------------------------------------------------
    # Food  (kg CO₂ per unit)
    # ------------------------------------------------------------------
    beef_meal_kg: float = 3.0
    """One beef-based meal."""

    dairy_serving_kg: float = 0.6
    """One dairy serving (glass of milk, portion of cheese, yoghurt, etc.)."""

    diet_base_omnivore_year: float = 1500.0
    """Annual baseline for an omnivore diet (excl. beef/dairy counted separately)."""

    diet_base_vegetarian_year: float = 1000.0
    """Annual baseline for a vegetarian diet."""

    diet_base_vegan_year: float = 700.0
    """Annual baseline for a vegan diet."""

    local_food_saving_rate: float = 0.10
    """
    Maximum fractional saving on food transport/packaging
    when 100 % of food is locally sourced.
    Applied as: diet_base × (local_food_percent / 100) × rate.
    """

    # ------------------------------------------------------------------
    # Household waste  (kg CO₂ per kg of waste sent to landfill/incineration)
    # ------------------------------------------------------------------
    waste_kg_co2_per_kg: float = 0.57
    """Average CO₂ from processing one kg of general household waste."""


# A single shared instance — import this in other modules.
FACTORS = EmissionFactors()

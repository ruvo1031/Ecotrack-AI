"""
ClimateRecommender — a lightweight, rule-based AI recommendation engine.

How it works
------------
1. The calculator returns per-category emissions as a dict.
2. The recommender sorts categories by kg (highest first).
3. It looks up each top category in RECOMMENDATION_MAP.
4. For each category it selects the top 2 actions.
5. Each action's 'reason' template is filled with the user's actual value,
   making the output feel personalised without any ML model.

No external API, database, or paid service is required.
"""

from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Recommendation:
    """
    A single climate-action recommendation.

    Attributes:
        category:   The emission category this targets (e.g. 'Air Travel').
        title:      Short action title shown to the user.
        description: Practical steps the user can take.
        reason:     Why this recommendation was generated for this user
                    (populated from the user's own emission value).
        saving_kg:  Estimated annual CO₂ saving from this action (kg/year).
    """

    category: str
    title: str
    description: str
    reason: str
    saving_kg: float


@dataclass
class _Action:
    """Internal template used to build a Recommendation."""

    title: str
    description: str
    reason_template: str   # use {kg:.0f} for the user's category value
    saving_kg: float


# ---------------------------------------------------------------------------
# RECOMMENDATION_MAP
# Maps each category name to a list of Action templates.
# All saving_kg values are rough annual estimates — clearly approximate.
# ---------------------------------------------------------------------------

_RECOMMENDATION_MAP: dict[str, list[_Action]] = {
    "Electricity": [
        _Action(
            title="Switch to a renewable energy tariff",
            description=(
                "Contact your electricity provider and ask about 100 % renewable "
                "tariffs. Many providers offer green energy at a similar price."
            ),
            reason_template=(
                "Your electricity use produces an estimated {kg:.0f} kg CO₂/year. "
                "Switching to renewables can cut this by up to 90 %."
            ),
            saving_kg=500,
        ),
        _Action(
            title="Reduce standby power and switch to LED lighting",
            description=(
                "Unplug devices when not in use, use smart power strips, "
                "and replace all bulbs with LED equivalents."
            ),
            reason_template=(
                "Small daily habits can reduce your electricity-related emissions "
                "(currently ~{kg:.0f} kg CO₂/year) by around 10–15 %."
            ),
            saving_kg=80,
        ),
        _Action(
            title="Use energy-efficient appliances",
            description=(
                "When replacing appliances, choose A-rated (or equivalent) "
                "energy-efficient models. Fridges, washing machines, and "
                "dishwashers make the biggest difference."
            ),
            reason_template=(
                "Upgrading to efficient appliances can cut your electricity "
                "emissions (estimated {kg:.0f} kg CO₂/year) by 15–25 %."
            ),
            saving_kg=120,
        ),
    ],
    "Private Vehicle": [
        _Action(
            title="Switch to public transport or cycling for short trips",
            description=(
                "For trips under 5 km, consider walking or cycling. "
                "For longer commutes, explore buses or trains which emit "
                "significantly less CO₂ per passenger."
            ),
            reason_template=(
                "Your private vehicle use produces an estimated {kg:.0f} kg CO₂/year. "
                "Replacing just 20 % of car trips with greener alternatives "
                "could save over 200 kg."
            ),
            saving_kg=250,
        ),
        _Action(
            title="Carpool or share rides",
            description=(
                "Sharing a car journey with one extra passenger halves the "
                "per-person emissions. Use carpool apps or coordinate with "
                "colleagues for commuting."
            ),
            reason_template=(
                "Carpooling your current driving distance (~{kg:.0f} kg CO₂/year) "
                "with one other person would cut your share nearly in half."
            ),
            saving_kg=300,
        ),
        _Action(
            title="Consider an electric or hybrid vehicle",
            description=(
                "Electric vehicles produce around 75 % less CO₂ per km "
                "than petrol cars when charged on average grid electricity — "
                "even more on renewables."
            ),
            reason_template=(
                "Switching from a petrol/diesel car to an EV could reduce "
                "your estimated vehicle emissions ({kg:.0f} kg CO₂/year) by up to 75 %."
            ),
            saving_kg=700,
        ),
    ],
    "Public Transport": [
        _Action(
            title="Choose train over bus for longer journeys",
            description=(
                "Trains typically emit about half as much CO₂ per km as buses. "
                "Where both options are available, the train is the greener choice."
            ),
            reason_template=(
                "Your public transport use produces an estimated {kg:.0f} kg CO₂/year. "
                "Shifting bus journeys to rail can reduce this meaningfully."
            ),
            saving_kg=60,
        ),
        _Action(
            title="Walk or cycle for short urban trips",
            description=(
                "For journeys under 3 km, walking or cycling produces zero "
                "direct emissions and benefits your health."
            ),
            reason_template=(
                "Replacing short bus trips with walking/cycling eliminates "
                "those emissions entirely."
            ),
            saving_kg=40,
        ),
    ],
    "Air Travel": [
        _Action(
            title="Replace short-haul flights with train travel",
            description=(
                "A 500 km train journey emits around 90 % less CO₂ than "
                "the equivalent flight. Book rail tickets early for the best prices."
            ),
            reason_template=(
                "Your flights produce an estimated {kg:.0f} kg CO₂/year — "
                "one of the highest-impact categories. Replacing even one "
                "short flight with a train saves ~200 kg."
            ),
            saving_kg=200,
        ),
        _Action(
            title="Reduce the number of flights per year",
            description=(
                "Consider combining trips, using video calls instead of "
                "business travel, or choosing holiday destinations reachable "
                "by surface transport."
            ),
            reason_template=(
                "Cutting your annual flights by even one long-haul trip "
                "could save up to 1,600 kg from your estimated {kg:.0f} kg/year."
            ),
            saving_kg=1_620,
        ),
        _Action(
            title="Choose economy class and direct routes",
            description=(
                "Business and first class seats have a larger CO₂ share due "
                "to space allocation. Non-stop flights also use less fuel "
                "than routes with layovers."
            ),
            reason_template=(
                "Booking economy and direct can meaningfully reduce the "
                "per-passenger emissions from your flights ({kg:.0f} kg CO₂/year)."
            ),
            saving_kg=150,
        ),
    ],
    "Food": [
        _Action(
            title="Reduce beef and lamb consumption",
            description=(
                "Beef has one of the highest carbon footprints of any food "
                "(around 27 kg CO₂ per kg of beef). Swapping two beef meals "
                "a week for chicken, fish, legumes, or tofu makes a big difference."
            ),
            reason_template=(
                "Food-related emissions are estimated at {kg:.0f} kg CO₂/year. "
                "Reducing beef intake is the single most impactful food change."
            ),
            saving_kg=300,
        ),
        _Action(
            title="Eat more plant-based meals",
            description=(
                "A plant-based meal typically produces 50–70 % less CO₂ "
                "than a meat-based meal. Try one or two meat-free days per week."
            ),
            reason_template=(
                "Moving towards a more plant-forward diet could reduce "
                "your food-related emissions ({kg:.0f} kg CO₂/year) by 20–30 %."
            ),
            saving_kg=250,
        ),
        _Action(
            title="Buy local and seasonal food",
            description=(
                "Food transported by air freight has a much higher footprint "
                "than locally grown produce. Choose seasonal and locally sourced "
                "products where possible."
            ),
            reason_template=(
                "Increasing local food sourcing reduces packaging and transport "
                "emissions from your food basket ({kg:.0f} kg CO₂/year)."
            ),
            saving_kg=80,
        ),
    ],
    "Household Waste": [
        _Action(
            title="Improve recycling habits",
            description=(
                "Separate paper, glass, metal, and plastics for recycling. "
                "Most councils provide clear guidance on what can be recycled. "
                "Recycling one tonne of waste saves around 1–2 tonnes of CO₂."
            ),
            reason_template=(
                "Your household waste produces an estimated {kg:.0f} kg CO₂/year. "
                "Improving recycling could cut this significantly."
            ),
            saving_kg=100,
        ),
        _Action(
            title="Start composting food and garden waste",
            description=(
                "Food waste in landfill produces methane, a potent greenhouse gas. "
                "Home composting or using a council food-waste bin keeps this "
                "material out of landfill."
            ),
            reason_template=(
                "Composting organic waste reduces the landfill contribution "
                "of your estimated {kg:.0f} kg CO₂/year waste footprint."
            ),
            saving_kg=75,
        ),
        _Action(
            title="Reduce single-use plastics and packaging",
            description=(
                "Choose products with minimal packaging, use reusable bags "
                "and containers, and avoid single-use plastics wherever possible."
            ),
            reason_template=(
                "Less packaging means less waste produced and fewer emissions "
                "from processing your current {kg:.0f} kg CO₂/year waste footprint."
            ),
            saving_kg=50,
        ),
    ],
}

# General tips shown when all categories are near zero
_GENERAL_TIPS: list[Recommendation] = [
    Recommendation(
        category="General",
        title="Track your footprint regularly",
        description="Update your data every few months to see how your habits change over time.",
        reason="Awareness is the first step to meaningful climate action.",
        saving_kg=0,
    ),
    Recommendation(
        category="General",
        title="Talk to friends and family about climate action",
        description=(
            "Sharing what you have learned about your own footprint can inspire "
            "others to take similar steps."
        ),
        reason="Collective action amplifies individual impact.",
        saving_kg=0,
    ),
    Recommendation(
        category="General",
        title="Support renewable energy policies",
        description=(
            "Contact your local representatives, sign petitions, and vote for "
            "policies that support renewable energy and public transport."
        ),
        reason="Systemic change requires both individual and political action.",
        saving_kg=0,
    ),
]


class ClimateRecommender:
    """
    A rule-based AI recommendation engine.

    It analyses the user's per-category emissions, identifies the top emitters,
    and returns personalised, actionable recommendations.

    This engine requires no external API, machine-learning model, or database.
    """

    def __init__(self, top_n: int = 3, actions_per_category: int = 2) -> None:
        """
        Args:
            top_n: Number of highest-emission categories to target.
            actions_per_category: Maximum recommendations returned per category.
        """
        self._top_n = top_n
        self._actions_per_category = actions_per_category

    def get_top_categories(self, emissions: dict[str, float]) -> list[str]:
        """
        Return the top N categories by estimated emissions, highest first.

        Categories with zero emissions are excluded.
        """
        non_zero = {k: v for k, v in emissions.items() if v > 0}
        sorted_cats = sorted(non_zero, key=lambda k: non_zero[k], reverse=True)
        return sorted_cats[: self._top_n]

    def get_recommendations(
        self, emissions: dict[str, float]
    ) -> list[Recommendation]:
        """
        Generate personalised recommendations based on the user's emissions.

        Args:
            emissions: Dict from FootprintCalculator.calc_all().

        Returns:
            A list of Recommendation objects, ordered by category priority.
        """
        top_categories = self.get_top_categories(emissions)

        if not top_categories:
            return _GENERAL_TIPS

        recommendations: list[Recommendation] = []
        for category in top_categories:
            actions = _RECOMMENDATION_MAP.get(category, [])
            category_kg = emissions.get(category, 0.0)
            for action in actions[: self._actions_per_category]:
                filled_reason = action.reason_template.format(kg=category_kg)
                recommendations.append(
                    Recommendation(
                        category=category,
                        title=action.title,
                        description=action.description,
                        reason=filled_reason,
                        saving_kg=action.saving_kg,
                    )
                )

        return recommendations

    @staticmethod
    def estimate_total_savings(recommendations: list[Recommendation]) -> float:
        """
        Return the sum of all estimated CO₂ savings from a recommendation list.

        Args:
            recommendations: Output of get_recommendations().

        Returns:
            Total estimated saving in kg CO₂/year.
        """
        return round(sum(r.saving_kg for r in recommendations), 2)

"""
FootprintCalculator — estimates CO₂ emissions for each consumption category.

All results are in kg CO₂ equivalent per year.

DISCLAIMER: These are simplified estimates for educational purposes only.
Actual emissions vary by region, technology, and individual behaviour.
"""

from models.emission_data import EmissionData
from models.user_profile import UserProfile
from core.emission_factors import FACTORS, EmissionFactors

# Category names — used as keys throughout the application
CATEGORY_ELECTRICITY = "Electricity"
CATEGORY_VEHICLE = "Private Vehicle"
CATEGORY_TRANSPORT = "Public Transport"
CATEGORY_FLIGHTS = "Air Travel"
CATEGORY_FOOD = "Food"
CATEGORY_WASTE = "Household Waste"

ALL_CATEGORIES: list[str] = [
    CATEGORY_ELECTRICITY,
    CATEGORY_VEHICLE,
    CATEGORY_TRANSPORT,
    CATEGORY_FLIGHTS,
    CATEGORY_FOOD,
    CATEGORY_WASTE,
]


class FootprintCalculator:
    """
    Calculates estimated annual CO₂ emissions from a user's EmissionData.

    Each `calc_*` method returns a float (kg CO₂/year) for one category.
    `calc_all()` returns a dict of all categories.
    `calc_total()` returns the grand total.

    Args:
        emission_data: The user's raw consumption inputs.
        user_profile: Needed for household_size (splits electricity) and diet_type.
        factors: Emission factors — defaults to the shared FACTORS constant.
    """

    def __init__(
        self,
        emission_data: EmissionData,
        user_profile: UserProfile,
        factors: EmissionFactors = FACTORS,
    ) -> None:
        self._data = emission_data
        self._profile = user_profile
        self._f = factors

    # ------------------------------------------------------------------
    # Individual category calculations
    # ------------------------------------------------------------------

    def calc_electricity_emissions(self) -> float:
        """
        Estimate annual electricity CO₂ emissions (kg/year).

        Formula:
            annual_kwh = kwh_per_month × 12
            factor     = renewable_factor if renewable else grid_factor
            result     = (annual_kwh × factor) ÷ household_size
        """
        annual_kwh = self._data.electricity_kwh_per_month * 12
        factor = (
            self._f.electricity_renewable_kwh
            if self._data.uses_renewable_energy
            else self._f.electricity_grid_kwh
        )
        household_size = max(1, self._profile.household_size)
        return round((annual_kwh * factor) / household_size, 2)

    def calc_vehicle_emissions(self) -> float:
        """
        Estimate annual private vehicle CO₂ emissions (kg/year).

        Formula:
            annual_km = km_per_week × 52
            result    = (annual_km × fuel_factor) ÷ passengers
        """
        if self._data.fuel_type == "none" or self._data.car_km_per_week == 0:
            return 0.0

        fuel_factors: dict[str, float] = {
            "petrol": self._f.vehicle_petrol_km,
            "diesel": self._f.vehicle_diesel_km,
            "electric": self._f.vehicle_electric_km,
        }
        factor = fuel_factors.get(self._data.fuel_type, self._f.vehicle_petrol_km)
        annual_km = self._data.car_km_per_week * 52
        passengers = max(1, self._data.car_passengers)
        return round((annual_km * factor) / passengers, 2)

    def calc_transport_emissions(self) -> float:
        """
        Estimate annual public transport CO₂ emissions (kg/year).

        Formula:
            result = (bus_km_per_week × 52 × bus_factor)
                   + (train_km_per_week × 52 × train_factor)
        """
        bus_annual = self._data.bus_km_per_week * 52 * self._f.bus_km
        train_annual = self._data.train_km_per_week * 52 * self._f.train_km
        return round(bus_annual + train_annual, 2)

    def calc_flight_emissions(self) -> float:
        """
        Estimate annual air travel CO₂ emissions (kg/year).

        Formula:
            result = (short_flights × short_factor)
                   + (long_flights  × long_factor)
        """
        short = self._data.short_flights_per_year * self._f.short_flight_kg
        long_ = self._data.long_flights_per_year * self._f.long_flight_kg
        return round(short + long_, 2)

    def calc_food_emissions(self) -> float:
        """
        Estimate annual food-related CO₂ emissions (kg/year).

        Formula:
            diet_base    = baseline for the user's diet type
            beef_annual  = beef_meals_per_week × 52 × beef_factor
            dairy_annual = dairy_servings_per_day × 365 × dairy_factor
            local_saving = diet_base × (local_food_percent ÷ 100) × saving_rate
            result       = diet_base + beef_annual + dairy_annual − local_saving
        """
        diet_bases: dict[str, float] = {
            "omnivore": self._f.diet_base_omnivore_year,
            "vegetarian": self._f.diet_base_vegetarian_year,
            "vegan": self._f.diet_base_vegan_year,
        }
        diet_base = diet_bases.get(
            self._profile.diet_type, self._f.diet_base_omnivore_year
        )

        beef_annual = self._data.beef_meals_per_week * 52 * self._f.beef_meal_kg
        dairy_annual = (
            self._data.dairy_servings_per_day * 365 * self._f.dairy_serving_kg
        )
        local_saving = (
            diet_base
            * (self._data.local_food_percent / 100)
            * self._f.local_food_saving_rate
        )

        total = diet_base + beef_annual + dairy_annual - local_saving
        return round(max(0.0, total), 2)

    def calc_waste_emissions(self) -> float:
        """
        Estimate annual household waste CO₂ emissions (kg/year).

        Formula:
            annual_waste   = waste_kg_per_week × 52
            effective      = annual_waste × (1 − recycling_percent ÷ 100)
            result         = effective × waste_factor
        """
        annual_waste = self._data.waste_kg_per_week * 52
        recycle_fraction = self._data.recycling_percent / 100
        effective_waste = annual_waste * (1 - recycle_fraction)
        return round(effective_waste * self._f.waste_kg_co2_per_kg, 2)

    # ------------------------------------------------------------------
    # Aggregated results
    # ------------------------------------------------------------------

    def calc_all(self) -> dict[str, float]:
        """
        Return estimated CO₂ emissions (kg/year) for every category.

        Returns:
            A dict mapping category name → kg CO₂/year.
        """
        return {
            CATEGORY_ELECTRICITY: self.calc_electricity_emissions(),
            CATEGORY_VEHICLE: self.calc_vehicle_emissions(),
            CATEGORY_TRANSPORT: self.calc_transport_emissions(),
            CATEGORY_FLIGHTS: self.calc_flight_emissions(),
            CATEGORY_FOOD: self.calc_food_emissions(),
            CATEGORY_WASTE: self.calc_waste_emissions(),
        }

    def calc_total(self) -> float:
        """
        Return the total estimated CO₂ footprint (kg/year).

        Returns:
            Sum of all category emissions, rounded to 2 decimal places.
        """
        return round(sum(self.calc_all().values()), 2)

    def get_highest_category(self) -> str:
        """
        Return the name of the category with the highest estimated emissions.

        Returns:
            Category name string, or 'None' if all categories are zero.
        """
        emissions = self.calc_all()
        if not any(v > 0 for v in emissions.values()):
            return "None"
        return max(emissions, key=lambda k: emissions[k])

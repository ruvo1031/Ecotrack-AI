"""
SustainabilityGoal and GoalTracker — goal creation and progress tracking.

A goal stores a baseline footprint and a reduction target (%).
Progress is measured by comparing the current footprint to the target.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Type

from utils.exceptions import ValidationError


@dataclass
class SustainabilityGoal:
    """
    Represents a single sustainability reduction goal.

    Attributes:
        baseline_kg:        The total estimated footprint when the goal was created (kg/year).
        reduction_percent:  Target reduction as a percentage (5–50).
        target_kg:          Calculated target: baseline × (1 − reduction/100).
        current_kg:         The most recent estimated footprint for progress tracking.
    """

    baseline_kg: float
    reduction_percent: int
    target_kg: float
    current_kg: float

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dictionary for JSON storage."""
        return {
            "baseline_kg": self.baseline_kg,
            "reduction_percent": self.reduction_percent,
            "target_kg": self.target_kg,
            "current_kg": self.current_kg,
        }

    @classmethod
    def from_dict(cls: Type["SustainabilityGoal"], data: dict[str, Any]) -> "SustainabilityGoal":
        """Reconstruct a SustainabilityGoal from a plain dictionary."""
        return cls(
            baseline_kg=float(data.get("baseline_kg", 0.0)),
            reduction_percent=int(data.get("reduction_percent", 10)),
            target_kg=float(data.get("target_kg", 0.0)),
            current_kg=float(data.get("current_kg", 0.0)),
        )


class GoalTracker:
    """
    Creates and tracks sustainability reduction goals.

    A goal is created from a baseline footprint and a desired reduction percentage.
    Progress is measured as how much of the required reduction has been achieved.
    """

    # ------------------------------------------------------------------
    # Goal management
    # ------------------------------------------------------------------

    @staticmethod
    def create_goal(baseline_kg: float, reduction_percent: int) -> SustainabilityGoal:
        """
        Create a new sustainability goal.

        Args:
            baseline_kg:        Current total footprint (kg/year).
            reduction_percent:  Desired reduction, 5–50 %.

        Returns:
            A SustainabilityGoal with target_kg calculated.

        Raises:
            ValidationError: If reduction_percent is outside the allowed range.
        """
        if not (5 <= reduction_percent <= 50):
            raise ValidationError(
                f"Reduction goal must be between 5 % and 50 %, got {reduction_percent} %."
            )
        target_kg = round(baseline_kg * (1 - reduction_percent / 100), 2)
        return SustainabilityGoal(
            baseline_kg=round(baseline_kg, 2),
            reduction_percent=reduction_percent,
            target_kg=target_kg,
            current_kg=round(baseline_kg, 2),
        )

    @staticmethod
    def update_progress(
        goal: SustainabilityGoal, current_kg: float
    ) -> SustainabilityGoal:
        """
        Update the goal's current footprint to reflect the latest calculation.

        Args:
            goal:       The existing goal to update.
            current_kg: The latest estimated footprint (kg/year).

        Returns:
            A new SustainabilityGoal with updated current_kg.
        """
        return SustainabilityGoal(
            baseline_kg=goal.baseline_kg,
            reduction_percent=goal.reduction_percent,
            target_kg=goal.target_kg,
            current_kg=round(max(0.0, current_kg), 2),
        )

    @staticmethod
    def get_progress_percent(goal: SustainabilityGoal) -> float:
        """
        Calculate how far the user has progressed toward their goal.

        Progress is 0.0 if they haven't improved, 100.0 if they've
        exactly hit the target, and can exceed 100 if they go further.

        Returns:
            A float between 0.0 and 100.0 (clamped, shown as percentage).
        """
        required_reduction = goal.baseline_kg - goal.target_kg
        if required_reduction <= 0:
            return 100.0
        achieved_reduction = goal.baseline_kg - goal.current_kg
        raw = (achieved_reduction / required_reduction) * 100
        return round(max(0.0, min(100.0, raw)), 1)

    @staticmethod
    def is_goal_met(goal: SustainabilityGoal) -> bool:
        """Return True if the current footprint is at or below the target."""
        return goal.current_kg <= goal.target_kg

    @staticmethod
    def get_status_message(goal: SustainabilityGoal) -> str:
        """Return a friendly status message about the goal's progress."""
        progress = GoalTracker.get_progress_percent(goal)
        remaining = max(0.0, goal.current_kg - goal.target_kg)

        if GoalTracker.is_goal_met(goal):
            return (
                f"🎉 Goal achieved! Your estimated footprint ({goal.current_kg:,.0f} kg) "
                f"is at or below your target of {goal.target_kg:,.0f} kg/year."
            )
        elif progress >= 50:
            return (
                f"You're {progress:.0f} % of the way to your goal. "
                f"You still need to reduce by ~{remaining:,.0f} kg CO₂/year."
            )
        else:
            return (
                f"You've made {progress:.0f} % progress toward your goal. "
                f"Keep going — you need to reduce by ~{remaining:,.0f} kg CO₂/year "
                f"to reach your target of {goal.target_kg:,.0f} kg."
            )
